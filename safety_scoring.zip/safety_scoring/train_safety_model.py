"""
Training Pipeline for Safety Score Prediction Model

This module provides a comprehensive training pipeline for the Safety Score Prediction Engine.
"""

import pandas as pd
import numpy as np
import os
import json
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import joblib

from dataset_generator import SafetyScoreDatasetGenerator
from safety_score_model import SafetyScoreEnsemble

class SafetyScoreTrainingPipeline:
    """Complete training pipeline for Safety Score Prediction Engine."""
    
    def __init__(self, config: dict = None):
        """Initialize the training pipeline."""
        self.config = config or self.get_default_config()
        self.generator = SafetyScoreDatasetGenerator(random_seed=self.config['random_seed'])
        self.engineer = SafetyScoreFeatureEngineer()
        self.model = SafetyScoreEnsemble(random_state=self.config['random_seed'])
        self.training_results = {}
        
    def get_default_config(self) -> dict:
        """Get default training configuration for simplified schema."""
        return {
            'random_seed': 42,
            'num_tourists': 500,  # Reduced for simplified schema
            'num_days': 14,       # Reduced for simplified schema
            'test_size': 0.2,
            'validation_size': 0.2,
            'feature_selection_method': 'random_forest',
            'num_features': 20,   # Reduced for simplified schema (25 fields - 5 target/ID fields)
            'cross_validation_folds': 3,  # Reduced for faster training
            'save_artifacts': True,
            'output_dir': 'safety_scoring_models',
            'schema_validation': True,  # Enable schema validation
            'expected_schema_fields': 25  # Expected number of schema fields
        }
    
    def generate_dataset(self) -> pd.DataFrame:
        """Generate the training dataset."""
        print("Generating Safety Score Dataset...")
        print(f"Configuration: {self.config['num_tourists']} tourists, {self.config['num_days']} days")
        
        df = self.generator.generate_tourist_data(
            num_tourists=self.config['num_tourists'],
            days=self.config['num_days']
        )
        
        print(f"Dataset generated: {df.shape[0]} records, {df['tourist_id'].nunique()} tourists")
        print(f"Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
        print(f"Safety score range: {df['safety_score'].min():.2f} - {df['safety_score'].max():.2f}")
        
        # Validate schema if enabled
        if self.config.get('schema_validation', False):
            self.validate_dataset_schema(df)
        
        return df
    
    def validate_dataset_schema(self, df: pd.DataFrame) -> bool:
        """Validate that the dataset matches the expected schema."""
        print("Validating dataset schema...")
        
        # Expected schema fields (25 fields)
        expected_schema_fields = [
            'tourist_id', 'timestamp', 'latitude', 'longitude', 'location_name', 'state',
            'hour', 'is_night', 'month', 'speed_kmh', 'time_since_last_checkin',
            'location_risk_level', 'zone_risk_score', 'weather_condition', 'weather_safety_impact',
            'visibility_score', 'temperature', 'humidity', 'tourist_profile', 'has_medical_condition',
            'tourist_density', 'local_event_risk', 'communication_events', 'safety_score',
            'safety_score_category'
        ]
        
        # Check for missing fields
        missing_fields = [f for f in expected_schema_fields if f not in df.columns]
        extra_fields = [f for f in df.columns if f not in expected_schema_fields]
        
        if missing_fields:
            print(f"⚠️ Missing schema fields: {missing_fields}")
            return False
        
        if extra_fields:
            print(f"⚠️ ℹ Extra fields found: {extra_fields}")
        
        # Validate data types and ranges
        validation_checks = [
            (df['safety_score'].min() >= 0, "Safety score should be >= 0"),
            (df['safety_score'].max() <= 100, "Safety score should be <= 100"),
            (df['latitude'].min() >= 20, "Latitude should be reasonable for Northeast India"),
            (df['latitude'].max() <= 30, "Latitude should be reasonable for Northeast India"),
            (df['longitude'].min() >= 85, "Longitude should be reasonable for Northeast India"),
            (df['longitude'].max() <= 100, "Longitude should be reasonable for Northeast India"),
            (df['hour'].min() >= 0, "Hour should be 0-23"),
            (df['hour'].max() <= 23, "Hour should be 0-23"),
            (df['month'].min() >= 1, "Month should be 1-12"),
            (df['month'].max() <= 12, "Month should be 1-12"),
            (df['speed_kmh'].min() >= 0, "Speed should be >= 0"),
            (df['zone_risk_score'].min() >= 0, "Zone risk score should be >= 0"),
            (df['zone_risk_score'].max() <= 1, "Zone risk score should be <= 1"),
            (df['weather_safety_impact'].min() >= 0, "Weather safety impact should be >= 0"),
            (df['weather_safety_impact'].max() <= 1, "Weather safety impact should be <= 1"),
            (df['visibility_score'].min() >= 0, "Visibility score should be >= 0"),
            (df['visibility_score'].max() <= 1, "Visibility score should be <= 1"),
            (df['humidity'].min() >= 0, "Humidity should be >= 0"),
            (df['humidity'].max() <= 100, "Humidity should be <= 100"),
            (df['tourist_density'].min() >= 0, "Tourist density should be >= 0"),
            (df['tourist_density'].max() <= 100, "Tourist density should be <= 100"),
            (df['local_event_risk'].min() >= 0, "Local event risk should be >= 0"),
            (df['local_event_risk'].max() <= 1, "Local event risk should be <= 1"),
            (df['communication_events'].min() >= 0, "Communication events should be >= 0")
        ]
        
        # Check categorical values
        categorical_checks = [
            (df['location_risk_level'].isin(['low', 'medium', 'high']).all(), "Invalid risk levels"),
            (df['weather_condition'].isin(['clear', 'light_rain', 'heavy_rain', 'storm', 'fog', 'snow']).all(), "Invalid weather conditions"),
            (df['tourist_profile'].isin(['beginner', 'moderate', 'experienced', 'adventure_seeker']).all(), "Invalid tourist profiles"),
            (df['safety_score_category'].isin(['Very Safe', 'Safe', 'Moderate Risk', 'High Risk', 'Very High Risk']).all(), "Invalid safety categories")
        ]
        
        # Run all validation checks
        all_checks = validation_checks + categorical_checks
        failed_checks = [check[1] for check in all_checks if not check[0]]
        
        if failed_checks:
            print(f"❌ Schema validation failed:")
            for failed_check in failed_checks:
                print(f"   - {failed_check}")
            return False
        
        print(f"✅ Schema validation passed - {len(expected_schema_fields)} fields validated")
        return True
    
    def prepare_data(self, df: pd.DataFrame) -> tuple:
        """Prepare training, validation, and test data."""
        print("Preparing training data...")
        
        # Engineer features
        df_engineered = self.engineer.engineer_features(df, 'safety_score')
        
        # Validate engineered features schema
        if self.config.get('schema_validation', False):
            print("Validating engineered features schema...")
            validation_result = self.model.validate_feature_set(df_engineered)
            if not validation_result['is_valid']:
                print(f"⚠️ Schema validation warning: {validation_result['missing_schema_features']}")
            else:
                print(f"✅ Engineered features schema validation passed")
        
        # Separate features and target
        feature_columns = [col for col in df_engineered.columns 
                          if col not in ['safety_score', 'safety_score_category', 'tourist_id', 'timestamp']]
        X = df_engineered[feature_columns]
        y = df_engineered['safety_score']
        
        # Handle missing values
        X = X.fillna(X.median())
        
        # Select features
        X_selected, selected_features = self.engineer.select_features(
            X, y, 
            method=self.config['feature_selection_method'],
            k=self.config['num_features']
        )
        
        # Split data: train -> validation + test, then validation -> validation + test
        X_temp, X_test, y_temp, y_test = train_test_split(
            X_selected, y, 
            test_size=self.config['test_size'], 
            random_state=self.config['random_seed']
        )
        
        X_train, X_val, y_train, y_val = train_test_split(
            X_temp, y_temp,
            test_size=self.config['validation_size'] / (1 - self.config['test_size']),
            random_state=self.config['random_seed']
        )
        
        print(f"Data split:")
        print(f"  Training: {X_train.shape[0]} samples")
        print(f"  Validation: {X_val.shape[0]} samples")
        print(f"  Test: {X_test.shape[0]} samples")
        print(f"  Features: {X_train.shape[1]}")
        
        return X_train, X_val, X_test, y_train, y_val, y_test, selected_features
    
    def train_model(self, X_train: pd.DataFrame, y_train: pd.Series,
                   X_val: pd.DataFrame, y_val: pd.Series) -> dict:
        """Train the ensemble model."""
        print("Training Safety Score Ensemble Model...")
        
        # Train the model
        individual_performance = self.model.train(
            X_train, y_train, 
            X_val, y_val, 
            optimize_weights=True
        )
        
        # Cross-validation
        cv_results = self.model.cross_validate(
            X_train, y_train, 
            cv=self.config['cross_validation_folds']
        )
        
        training_results = {
            'individual_performance': individual_performance,
            'cross_validation': cv_results,
            'ensemble_weights': self.model.ensemble_weights,
            'feature_count': X_train.shape[1]
        }
        
        print("Model training completed!")
        return training_results
    
    def evaluate_model(self, X_test: pd.DataFrame, y_test: pd.Series) -> dict:
        """Evaluate the trained model."""
        print("Evaluating model performance...")
        
        # Get predictions
        y_pred = self.model.predict(X_test)
        
        # Calculate metrics
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        rmse = np.sqrt(np.mean((y_test - y_pred) ** 2))
        mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100
        
        # Accuracy within different thresholds
        accuracy_5 = np.mean(np.abs(y_test - y_pred) <= 5) * 100
        accuracy_10 = np.mean(np.abs(y_test - y_pred) <= 10) * 100
        
        # Safety score distribution analysis
        score_ranges = {
            'very_safe': np.mean((y_pred >= 80) & (y_test >= 80)),
            'safe': np.mean((y_pred >= 60) & (y_pred < 80) & (y_test >= 60) & (y_test < 80)),
            'moderate_risk': np.mean((y_pred >= 40) & (y_pred < 60) & (y_test >= 40) & (y_test < 60)),
            'high_risk': np.mean((y_pred >= 20) & (y_pred < 40) & (y_test >= 20) & (y_test < 40)),
            'very_high_risk': np.mean((y_pred < 20) & (y_test < 20))
        }
        
        evaluation_results = {
            'mae': mae,
            'rmse': rmse,
            'r2': r2,
            'mape': mape,
            'accuracy_5': accuracy_5,
            'accuracy_10': accuracy_10,
            'score_distribution_accuracy': score_ranges,
            'predictions': {
                'actual_mean': y_test.mean(),
                'predicted_mean': y_pred.mean(),
                'actual_std': y_test.std(),
                'predicted_std': y_pred.std()
            }
        }
        
        print("Model Evaluation Results:")
        print(f"  MAE: {mae:.4f}")
        print(f"  RMSE: {rmse:.4f}")
        print(f"  R²: {r2:.4f}")
        print(f"  MAPE: {mape:.2f}%")
        print(f"  Accuracy (±5): {accuracy_5:.2f}%")
        print(f"  Accuracy (±10): {accuracy_10:.2f}%")
        
        return evaluation_results
    
    def test_model_inference(self, X_test: pd.DataFrame) -> dict:
        """Test model inference capabilities."""
        print("Testing model inference...")
        
        # Test single predictions
        sample_predictions = []
        for i in range(min(5, len(X_test))):
            sample_features = X_test.iloc[i].to_dict()
            prediction = self.model.predict_single(sample_features)
            sample_predictions.append(prediction)
        
        # Test batch predictions
        batch_predictions = self.model.predict(X_test)
        
        inference_results = {
            'sample_predictions': sample_predictions,
            'batch_prediction_stats': {
                'mean': float(np.mean(batch_predictions)),
                'std': float(np.std(batch_predictions)),
                'min': float(np.min(batch_predictions)),
                'max': float(np.max(batch_predictions))
            }
        }
        
        print("Inference testing completed!")
        return inference_results
    
    def test_schema_based_predictions(self) -> dict:
        """Test predictions using schema-based sample records."""
        print("Testing schema-based predictions...")
        
        # Generate sample records using model's schema method
        sample_records = []
        for i in range(5):
            sample_record = self.model.create_sample_record()
            sample_records.append(sample_record)
        
        # Test predictions on schema-based records
        schema_predictions = []
        for record in sample_records:
            prediction = self.model.predict_single(record)
            schema_predictions.append({
                'input_record': record,
                'prediction': prediction
            })
        
        # Validate prediction structure
        for pred in schema_predictions:
            assert 'safety_score' in pred['prediction'], "Prediction should have safety_score"
            assert 'safety_category' in pred['prediction'], "Prediction should have safety_category"
            assert 'contributing_factors' in pred['prediction'], "Prediction should have contributing_factors"
            assert 'confidence' in pred['prediction'], "Prediction should have confidence"
            
            # Validate ranges
            assert 0 <= pred['prediction']['safety_score'] <= 100, "Safety score should be 0-100"
            assert 0 <= pred['prediction']['confidence'] <= 100, "Confidence should be 0-100"
        
        schema_results = {
            'sample_predictions': schema_predictions,
            'prediction_stats': {
                'mean_score': float(np.mean([p['prediction']['safety_score'] for p in schema_predictions])),
                'mean_confidence': float(np.mean([p['prediction']['confidence'] for p in schema_predictions])),
                'score_range': {
                    'min': float(min([p['prediction']['safety_score'] for p in schema_predictions])),
                    'max': float(max([p['prediction']['safety_score'] for p in schema_predictions]))
                }
            }
        }
        
        print("Schema-based prediction testing completed!")
        return schema_results
    
    def save_artifacts(self, selected_features: list, training_results: dict, 
                      evaluation_results: dict, inference_results: dict):
        """Save all training artifacts."""
        if not self.config['save_artifacts']:
            return
        
        # Create output directory
        os.makedirs(self.config['output_dir'], exist_ok=True)
        
        # Save model
        model_path = os.path.join(self.config['output_dir'], 'safety_score_ensemble.pkl')
        self.model.save_model(model_path)
        
        # Save preprocessing artifacts
        preprocessing_path = os.path.join(self.config['output_dir'], 'preprocessing_artifacts.pkl')
        self.engineer.save_preprocessing_artifacts(preprocessing_path)
        
        # Save feature information
        feature_info = {
            'selected_features': selected_features,
            'feature_importance': self.model.feature_importance.to_dict() if self.model.feature_importance is not None else None,
            'ensemble_weights': self.model.ensemble_weights
        }
        
        with open(os.path.join(self.config['output_dir'], 'feature_info.json'), 'w') as f:
            json.dump(feature_info, f, indent=2, default=str)
        
        # Save schema template
        if self.config.get('schema_validation', False):
            schema_path = os.path.join(self.config['output_dir'], 'safety_score_schema.json')
            self.model.save_schema_template(schema_path)
        
        # Save training results
        all_results = {
            'config': self.config,
            'schema_info': {
                'schema_validation_enabled': self.config.get('schema_validation', False),
                'expected_schema_fields': self.config.get('expected_schema_fields', 25),
                'schema_version': '1.0'
            },
            'training_results': training_results,
            'evaluation_results': evaluation_results,
            'inference_results': inference_results,
            'timestamp': datetime.now().isoformat()
        }
        
        with open(os.path.join(self.config['output_dir'], 'training_results.json'), 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        print(f"All artifacts saved to {self.config['output_dir']}/")
    
    def run_training_pipeline(self) -> dict:
        """Run the complete training pipeline."""
        print("Starting Safety Score Prediction Model Training Pipeline")
        print("=" * 60)
        
        try:
            # Step 1: Generate dataset
            df = self.generate_dataset()
            
            # Step 2: Prepare data
            X_train, X_val, X_test, y_train, y_val, y_test, selected_features = self.prepare_data(df)
            
            # Step 3: Train model
            training_results = self.train_model(X_train, y_train, X_val, y_val)
            
            # Step 4: Evaluate model
            evaluation_results = self.evaluate_model(X_test, y_test)
            
            # Step 5: Test inference
            inference_results = self.test_model_inference(X_test)
            
            # Step 6: Test schema-based predictions
            schema_results = self.test_schema_based_predictions()
            
            # Step 7: Save artifacts
            self.save_artifacts(selected_features, training_results, evaluation_results, inference_results)
            
            # Compile final results
            final_results = {
                'status': 'success',
                'config': self.config,
                'training_results': training_results,
                'evaluation_results': evaluation_results,
                'inference_results': inference_results,
                'schema_results': schema_results,
                'selected_features': selected_features,
                'timestamp': datetime.now().isoformat()
            }
            
            print("=" * 60)
            print("Training Pipeline Completed Successfully! (Schema-Based)")
            print(f"Final MAE: {evaluation_results['mae']:.4f}")
            print(f"Final R²: {evaluation_results['r2']:.4f}")
            print(f"Accuracy (±5): {evaluation_results['accuracy_5']:.2f}%")
            print(f"Schema validation: {self.config.get('expected_schema_fields', 25)} fields validated")
            print(f"Schema-based predictions: {len(schema_results['sample_predictions'])} samples tested")
            
            return final_results
            
        except Exception as e:
            error_results = {
                'status': 'error',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
            print(f"Training pipeline failed: {e}")
            return error_results

def main():
    """Run the training pipeline with schema-based configuration."""
    # Configuration for schema-based training
    config = {
        'random_seed': 42,
        'num_tourists': 300,  # Reduced for schema-based training
        'num_days': 10,       # Reduced for schema-based training
        'test_size': 0.2,
        'validation_size': 0.2,
        'feature_selection_method': 'random_forest',
        'num_features': 20,   # Reduced for simplified schema (25 fields - 5 target/ID fields)
        'cross_validation_folds': 3,
        'save_artifacts': True,
        'output_dir': 'safety_scoring_models',
        'schema_validation': True,  # Enable schema validation
        'expected_schema_fields': 25  # Expected number of schema fields
    }
    
    # Run training pipeline
    pipeline = SafetyScoreTrainingPipeline(config)
    results = pipeline.run_training_pipeline()
    
    if results['status'] == 'success':
        print("\nSchema-based training completed successfully!")
        print(f"Model artifacts saved to: {config['output_dir']}/")
        print(f"Schema validation: {config['expected_schema_fields']} fields validated")
        print(f"Schema template saved: safety_score_schema.json")
    else:
        print(f"\nTraining failed: {results['error']}")

if __name__ == "__main__":
    main()

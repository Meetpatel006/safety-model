"""
Main entry point for the Safety Score Prediction API service.
This module handles server startup, configuration, and initialization.
"""

import uvicorn
import os
from safety_scoring.api_service import app, load_model_and_preprocessing
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('safety_score_api.log')
    ]
)

logger = logging.getLogger(__name__)

def configure_api():
    """Configure API settings and environment."""
    # Set environment variables if needed
    os.environ.setdefault('MODEL_PATH', 'safety_scoring_models/safety_score_ensemble.pkl')
    os.environ.setdefault('PREPROCESSING_PATH', 'safety_scoring_models/preprocessing_artifacts.pkl')
    
    # Ensure model directories exist
    os.makedirs('safety_scoring_models', exist_ok=True)
    
    # Additional configuration can be added here
    logger.info("API configuration completed")

def main():
    """Main entry point for the API service."""
    try:
        # Configure API settings
        configure_api()
        
        # Load model and preprocessing artifacts
        if not load_model_and_preprocessing():
            logger.error("Failed to load model and preprocessing artifacts")
            return
        
        # Define API server settings
        host = os.getenv('API_HOST', '0.0.0.0')
        port = int(os.getenv('API_PORT', '8000'))
        reload = os.getenv('API_RELOAD', 'False').lower() == 'true'
        
        logger.info(f"Starting Safety Score API server on {host}:{port}")
        
        # Run the API server
        uvicorn.run(
            "api:app",
            host=host,
            port=port,
            reload=reload,
            log_level="info"
        )
        
    except Exception as e:
        logger.error(f"Failed to start API server: {str(e)}")
        raise

if __name__ == "__main__":
    main()

"""
Safety Score Prediction Model

This module implements the Random Forest + XGBoost ensemble model for safety score prediction
as specified in the ml_model_docs.md requirements.
"""

import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score, GridSearchCV
import xgboost as xgb
from typing import Tuple, Dict, List
import warnings
warnings.filterwarnings('ignore')

class SafetyScoreEnsemble:
    """Ensemble model combining Random Forest and XGBoost for safety score prediction."""
    
    def __init__(self, random_state: int = 42):
        """Initialize the ensemble model."""
        self.random_state = random_state
        self.rf_model = None
        self.xgb_model = None
        self.ensemble_weights = None
        self.feature_importance = None
        self.is_trained = False
    # canonical list of feature names expected by the model (populated when saving/loading or training)
        self.feature_names = None
        
    def create_random_forest_model(self, **params) -> RandomForestRegressor:
        """Create and configure Random Forest model."""
        default_params = {
            'n_estimators': 150,  # Reduced for simplified features
            'max_depth': 12,      # Reduced for simplified features
            'min_samples_split': 3,
            'min_samples_leaf': 1,
            'max_features': 'sqrt',
            'bootstrap': True,
            'random_state': self.random_state,
            'n_jobs': -1
        }
        default_params.update(params)
        
        return RandomForestRegressor(**default_params)
    
    def create_xgboost_model(self, **params) -> xgb.XGBRegressor:
        """Create and configure XGBoost model."""
        default_params = {
            'n_estimators': 150,  # Reduced for simplified features
            'max_depth': 6,       # Reduced for simplified features
            'learning_rate': 0.1,
            'subsample': 0.9,
            'colsample_bytree': 0.9,
            'reg_alpha': 0.05,
            'reg_lambda': 0.05,
            'random_state': self.random_state,
            'n_jobs': -1
        }
        default_params.update(params)
        
        return xgb.XGBRegressor(**default_params)
    
    def train_individual_models(self, X_train: pd.DataFrame, y_train: pd.Series,
                              X_val: pd.DataFrame = None, y_val: pd.Series = None) -> Dict:
        """Train individual Random Forest and XGBoost models."""
        print("Training Random Forest model...")
        
        # Train Random Forest
        self.rf_model = self.create_random_forest_model()
        self.rf_model.fit(X_train, y_train)
        
        # Train XGBoost
        print("Training XGBoost model...")
        self.xgb_model = self.create_xgboost_model()
        
        if X_val is not None and y_val is not None:
            # Use validation set for early stopping
            self.xgb_model.fit(
                X_train, y_train,
                eval_set=[(X_val, y_val)],
                early_stopping_rounds=20,
                verbose=False
            )
        else:
            self.xgb_model.fit(X_train, y_train)
        
        # Calculate individual model performance
        rf_pred = self.rf_model.predict(X_train)
        xgb_pred = self.xgb_model.predict(X_train)
        
        rf_mae = mean_absolute_error(y_train, rf_pred)
        xgb_mae = mean_absolute_error(y_train, xgb_pred)
        
        print(f"Random Forest MAE: {rf_mae:.4f}")
        print(f"XGBoost MAE: {xgb_mae:.4f}")
        
        return {
            'rf_mae': rf_mae,
            'xgb_mae': xgb_mae,
            'rf_r2': r2_score(y_train, rf_pred),
            'xgb_r2': r2_score(y_train, xgb_pred)
        }
    
    def optimize_ensemble_weights(self, X_val: pd.DataFrame, y_val: pd.Series) -> Tuple[float, float]:
        """Optimize ensemble weights using validation data."""
        print("Optimizing ensemble weights...")
        
        # Get predictions from both models
        rf_pred = self.rf_model.predict(X_val)
        xgb_pred = self.xgb_model.predict(X_val)
        
        # Grid search for optimal weights
        best_mae = float('inf')
        best_weights = (0.5, 0.5)
        
        # Test different weight combinations
        weight_combinations = [
            (0.3, 0.7), (0.4, 0.6), (0.5, 0.5), (0.6, 0.4), (0.7, 0.3)
        ]
        
        for rf_weight, xgb_weight in weight_combinations:
            ensemble_pred = rf_weight * rf_pred + xgb_weight * xgb_pred
            mae = mean_absolute_error(y_val, ensemble_pred)
            
            if mae < best_mae:
                best_mae = mae
                best_weights = (rf_weight, xgb_weight)
        
        self.ensemble_weights = best_weights
        print(f"Optimal weights - RF: {best_weights[0]:.2f}, XGB: {best_weights[1]:.2f}")
        print(f"Validation MAE with optimal weights: {best_mae:.4f}")
        
        return best_weights
    
    def train(self, X_train: pd.DataFrame, y_train: pd.Series,
              X_val: pd.DataFrame = None, y_val: pd.Series = None,
              optimize_weights: bool = True) -> Dict:
        """Train the ensemble model."""
        print("Training Safety Score Ensemble Model...")
        
        # Train individual models
        individual_performance = self.train_individual_models(X_train, y_train, X_val, y_val)
        
        # Optimize ensemble weights if validation data is available
        if optimize_weights and X_val is not None and y_val is not None:
            self.optimize_ensemble_weights(X_val, y_val)
        else:
            # Use equal weights as default
            self.ensemble_weights = (0.5, 0.5)
            print("Using equal weights (0.5, 0.5) for ensemble")
        
        # Calculate feature importance
        self.calculate_feature_importance(X_train.columns)
        
        self.is_trained = True
        print("Ensemble model training completed!")
        
        return individual_performance
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Make predictions using the ensemble model."""
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        # Ensure DataFrame columns align with feature_names expected by estimators
        X_proc = X.copy()
        if self.feature_names:
            # Add any missing columns with zeros and drop extras, preserving order
            for col in self.feature_names:
                if col not in X_proc.columns:
                    X_proc[col] = 0
            # Reorder/limit to feature_names
            X_proc = X_proc[self.feature_names]
        else:
            # If no declared feature_names, attempt to infer from rf_model if possible
            try:
                if hasattr(self.rf_model, 'feature_names_in_'):
                    self.feature_names = list(self.rf_model.feature_names_in_)
                    for col in self.feature_names:
                        if col not in X_proc.columns:
                            X_proc[col] = 0
                    X_proc = X_proc[self.feature_names]
            except Exception:
                # fallback: use X as-is
                X_proc = X.copy()

        # Check if models exist before calling predict
        if self.rf_model is None and self.xgb_model is None:
            raise ValueError("No models available for prediction. Both rf_model and xgb_model are None.")
            
        # Get predictions from available models
        if self.rf_model is not None:
            rf_pred = self.rf_model.predict(X_proc)
        else:
            rf_pred = np.zeros(len(X_proc))
            
        if self.xgb_model is not None:
            xgb_pred = self.xgb_model.predict(X_proc)
        else:
            xgb_pred = np.zeros(len(X_proc))
        
        # Default weights if not set
        if self.ensemble_weights is None:
            if self.rf_model is not None and self.xgb_model is not None:
                self.ensemble_weights = (0.5, 0.5)
            elif self.rf_model is not None:
                self.ensemble_weights = (1.0, 0.0)
            elif self.xgb_model is not None:
                self.ensemble_weights = (0.0, 1.0)
            else:
                self.ensemble_weights = (0.5, 0.5)  # Should not reach here due to earlier check
        
        # Combine predictions with optimized weights
        ensemble_pred = (self.ensemble_weights[0] * rf_pred + 
                        self.ensemble_weights[1] * xgb_pred)
        
        return ensemble_pred
    
    def _handle_missing_features(self, feature_df: pd.DataFrame) -> pd.DataFrame:
        """Handle missing features by filling with appropriate defaults based on schema."""
        # Default values based on the schema structure
        default_values = {
            # Core identification
            'tourist_id': 'unknown_tourist',
            'timestamp': pd.Timestamp.now(),
            
            # Location data
            'latitude': 23.8315,  # Default to Agartala
            'longitude': 91.2862,
            'location_name': 'Agartala',
            'state': 'Tripura',
            
            # Temporal features
            'hour': 12,  # Default to noon
            'is_night': False,
            'month': 6,  # Default to June
            
            # Location and movement features
            'speed_kmh': 5.0,
            'time_since_last_checkin': 30,
            'location_risk_level': 'medium',
            'zone_risk_score': 0.5,
            
            # Weather and environmental features
            'weather_condition': 'clear',
            'weather_safety_impact': 0.3,
            'visibility_score': 0.8,
            'temperature': 25.0,
            'humidity': 60.0,
            
            # Tourist profile features
            'tourist_profile': 'moderate',
            'has_medical_condition': False,
            
            # Environmental context
            'tourist_density': 50,
            'local_event_risk': 0.2,
            
            # Behavioral features
            'communication_events': 2,
            
            # Target variable (will be predicted)
            'safety_score': 70.0,
            'safety_score_category': 'Safe'
        }
        
        # Fill missing columns with default values
        for col, default_val in default_values.items():
            if col not in feature_df.columns:
                feature_df[col] = default_val
        
        return feature_df
    
    def predict_single(self, features: Dict) -> Dict:
        """Make prediction for a single tourist instance."""
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        # Check if we have at least one model
        if self.rf_model is None and self.xgb_model is None:
            raise ValueError("No models available for prediction. Both rf_model and xgb_model are None.")
            
        # Convert features to DataFrame
        feature_df = pd.DataFrame([features])

        # Handle missing features by filling with defaults
        feature_df = self._handle_missing_features(feature_df)

        # Try to ensure the DataFrame contains the encoded/engineered feature names
        try:
            feature_df = self._ensure_feature_names_in_df(feature_df)
        except Exception as e:
            # best-effort: continue if helper not available or fails
            print(f"Warning during feature name processing: {str(e)}")
            pass

        # If feature_names not set, attempt to infer from saved feature_importance or underlying estimators
        if not self.feature_names:
            # Try to infer from feature_importance DataFrame
            try:
                if self.feature_importance is not None and hasattr(self.feature_importance, 'feature'):
                    self.feature_names = list(self.feature_importance['feature'])
            except Exception as e:
                print(f"Warning during feature name inference: {str(e)}")
                pass
            
            # Try to infer from rf_model if available
            if not self.feature_names and self.rf_model is not None:
                try:
                    if hasattr(self.rf_model, 'feature_names_in_'):
                        self.feature_names = list(self.rf_model.feature_names_in_)
                except Exception as e:
                    print(f"Warning during RF model feature name extraction: {str(e)}")
                    pass

        try:
            # Align feature_df columns and call predict
            safety_score = self.predict(feature_df)[0]
            
            # Categorize safety score
            safety_category = self.categorize_safety_score(safety_score)
            
            # Try to get contributing factors - use empty list as fallback
            try:
                contributing_factors = self.get_contributing_factors(feature_df)
            except Exception as e:
                print(f"Error getting contributing factors: {str(e)}")
                # Create fallback contributing factors
                contributing_factors = []
                for i, col in enumerate(feature_df.columns[:5]):
                    contributing_factors.append({
                        'factor': col,
                        'importance': 1.0 / (i + 1),  # Dummy importance values
                        'value': float(feature_df[col].iloc[0]) if pd.notnull(feature_df[col].iloc[0]) else 0.0
                    })
            
            # Try to calculate confidence or use a default
            try:
                confidence = self.calculate_prediction_confidence(feature_df)
            except Exception as e:
                print(f"Error calculating confidence: {str(e)}")
                confidence = 80.0  # Default confidence
                
            return {
                'safety_score': round(safety_score, 2),
                'safety_category': safety_category,
                'contributing_factors': contributing_factors,
                'confidence': confidence
            }
        except Exception as e:
            print(f"Error during prediction: {str(e)}")
            # Provide fallback prediction with warning
            return {
                'safety_score': 50.0,  # Neutral score
                'safety_category': 'Moderate Risk',
                'contributing_factors': [
                    {'factor': 'error', 'importance': 1.0, 'value': 0.0}
                ],
                'confidence': 10.0,  # Low confidence due to error
                'error': f"Prediction failed: {str(e)}"
            }

    def _ensure_feature_names_in_df(self, feature_df: pd.DataFrame) -> pd.DataFrame:
        df = feature_df.copy()

        # Simple mappings consistent with feature_engineering.py
        risk_map = {'low': 0, 'medium': 1, 'high': 2}
        profile_map = {'beginner': 0, 'moderate': 1, 'experienced': 2, 'adventure_seeker': 3}
        weather_map = {'clear': 0, 'light_rain': 1, 'heavy_rain': 2, 'storm': 3, 'fog': 4, 'snow': 5}

    # Map categorical base columns to numeric values (avoid creating duplicate encoded columns)
        if 'location_risk_level' in df.columns:
            df['location_risk_level'] = df['location_risk_level'].map(risk_map).fillna(0).astype(int)

        if 'tourist_profile' in df.columns:
            df['tourist_profile'] = df['tourist_profile'].map(profile_map).fillna(1).astype(int)

        if 'weather_condition' in df.columns:
            df['weather_condition'] = df['weather_condition'].map(weather_map).fillna(0).astype(int)

        # Optionally create a numeric safety category column for downstream models
        if 'safety_score' in df.columns and 'safety_score_category' not in df.columns:
            def cat_enc(v):
                try:
                    v = float(v)
                except Exception:
                    return 1
                if v >= 80:
                    return 'Very Safe'
                if v >= 60:
                    return 'Safe'
                if v >= 40:
                    return 'Moderate Risk'
                if v >= 20:
                    return 'High Risk'
                return 'Very High Risk'
            df['safety_score_category'] = df['safety_score'].apply(cat_enc)

        # If feature_names list exists, ensure all those columns exist; fill missing with 0
        if self.feature_names:
            for col in self.feature_names:
                if col not in df.columns:
                    df[col] = 0

        return df
    
    def categorize_safety_score(self, score: float) -> str:
        """Categorize safety score into risk levels."""
        if score >= 80:
            return 'Very Safe'
        elif score >= 60:
            return 'Safe'
        elif score >= 40:
            return 'Moderate Risk'
        elif score >= 20:
            return 'High Risk'
        else:
            return 'Very High Risk'
    
    def get_contributing_factors(self, X: pd.DataFrame) -> List[Dict]:
        """Get top contributing factors for the prediction."""
        if not self.is_trained:
            return []
            
        # If we don't have any models, return basic factors
        if self.rf_model is None and self.xgb_model is None:
            return self._get_fallback_contributing_factors(X)
            
        # Create feature importance arrays - prioritize using feature names
        feature_names = list(X.columns)
        n_features = len(feature_names)
            
        # Initialize arrays with the correct dimension
        rf_importance = np.zeros(n_features)
        xgb_importance = np.zeros(n_features)
            
        # Try to get RF importance if available
        if self.rf_model is not None and hasattr(self.rf_model, 'feature_importances_'):
            rf_model_n_features = len(self.rf_model.feature_importances_)
            
            # If RF model has fewer features than X, pad with zeros
            if rf_model_n_features <= n_features:
                rf_importance[:rf_model_n_features] = self.rf_model.feature_importances_
            else:
                # If RF model has more features, truncate
                rf_importance = self.rf_model.feature_importances_[:n_features]
        else:
            print("Warning: RF model missing or has no feature_importances_ attribute")
            
        # Try to get XGB importance if available  
        if self.xgb_model is not None and hasattr(self.xgb_model, 'feature_importances_'):
            xgb_model_n_features = len(self.xgb_model.feature_importances_)
            
            # If XGB model has fewer features than X, pad with zeros
            if xgb_model_n_features <= n_features:
                xgb_importance[:xgb_model_n_features] = self.xgb_model.feature_importances_
            else:
                # If XGB model has more features, truncate
                xgb_importance = self.xgb_model.feature_importances_[:n_features]
        else:
            print("Warning: XGB model missing or has no feature_importances_ attribute")
            
        # Calculate weighted importance using the ensemble weights or default to available model
        if self.ensemble_weights is None:
            if self.rf_model is not None and self.xgb_model is not None:
                self.ensemble_weights = (0.5, 0.5)
            elif self.rf_model is not None:
                self.ensemble_weights = (1.0, 0.0)
            elif self.xgb_model is not None:
                self.ensemble_weights = (0.0, 1.0)
            else:
                self.ensemble_weights = (0.5, 0.5)
        
        # Check that both arrays are the same length before combining
        if len(rf_importance) != len(xgb_importance):
            print(f"Error: Cannot combine importance arrays of different lengths: RF={len(rf_importance)}, XGB={len(xgb_importance)}")
            # Use the non-zero array if one is available, otherwise use RF array
            if np.any(rf_importance):
                weighted_importance = rf_importance
            elif np.any(xgb_importance):
                weighted_importance = xgb_importance
            else:
                # Both arrays are zeros, use rf_importance
                weighted_importance = rf_importance
        else:        
            weighted_importance = (self.ensemble_weights[0] * rf_importance + 
                                 self.ensemble_weights[1] * xgb_importance)
        
        # Get top 5 contributing factors
        feature_names = X.columns
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': weighted_importance
        }).sort_values('importance', ascending=False)
        
        top_factors = []
        for _, row in importance_df.head(5).iterrows():
            feature_name = row['feature']
            importance = row['importance']
            
            # Get feature value for interpretation
            feature_value = X[feature_name].iloc[0] if len(X) > 0 else 0
            
            # Handle Timestamp objects
            if isinstance(feature_value, pd.Timestamp):
                feature_value = feature_value.hour  # Use hour of day as a numeric value
            
            # Ensure numeric value
            try:
                feature_value = float(feature_value)
            except (TypeError, ValueError):
                # Handle non-numeric values by converting to a reasonable numeric representation
                if isinstance(feature_value, bool):
                    feature_value = 1.0 if feature_value else 0.0
                elif isinstance(feature_value, str):
                    # Simple string hashing to numeric value between 0-1
                    feature_value = sum(ord(c) for c in feature_value) % 100 / 100.0
                else:
                    feature_value = 0.0
            
            top_factors.append({
                'factor': feature_name,
                'importance': round(importance, 4),
                'value': round(feature_value, 4) if not np.isnan(feature_value) else 0.0
            })
        
        return top_factors
        
    def _get_fallback_contributing_factors(self, X: pd.DataFrame) -> List[Dict]:
        """Generate fallback contributing factors when no model is available."""
        # Use the most commonly important features based on domain knowledge
        key_features = [
            'location_risk_level', 'weather_condition', 'is_night',
            'tourist_density', 'weather_safety_impact', 'visibility_score'
        ]
        
        # Find which of these are in the dataframe
        available_features = [f for f in key_features if f in X.columns]
        
        # If none are available, use the first 5 columns
        if not available_features and len(X.columns) > 0:
            available_features = list(X.columns)[:5]
        
        top_factors = []
        for i, feature in enumerate(available_features[:5]):  # Use up to 5 features
            # Get feature value
            feature_value = X[feature].iloc[0] if len(X) > 0 else 0
            
            # Handle Timestamp objects
            if isinstance(feature_value, pd.Timestamp):
                feature_value = feature_value.hour  # Use hour of day as a numeric value
                
            # Ensure numeric value
            try:
                feature_value = float(feature_value)
            except (TypeError, ValueError):
                # Handle non-numeric values
                if isinstance(feature_value, bool):
                    feature_value = 1.0 if feature_value else 0.0
                elif isinstance(feature_value, str):
                    # Simple string hashing to numeric value between 0-1
                    feature_value = sum(ord(c) for c in feature_value) % 100 / 100.0
                else:
                    feature_value = 0.0
            
            # Calculate a mock importance - decreasing with index
            importance = 1.0 / (i + 1)
            
            top_factors.append({
                'factor': feature,
                'importance': round(importance, 4),
                'value': round(feature_value, 4) if not np.isnan(feature_value) else 0.0
            })
        
        return top_factors
    
    def calculate_prediction_confidence(self, X: pd.DataFrame) -> float:
        """Calculate confidence score for the prediction."""
        if not self.is_trained:
            return 0.0
            
        # Check if models are available
        if self.rf_model is None and self.xgb_model is None:
            return 50.0  # Default medium confidence when no models are available
        
        # Get predictions from available models
        feature_coverage = (X.notna().sum().sum()) / (X.shape[0] * X.shape[1])
        
        # If both models are available, use agreement to determine confidence
        if self.rf_model is not None and self.xgb_model is not None:
            try:
                rf_pred = self.rf_model.predict(X)
                xgb_pred = self.xgb_model.predict(X)
                
                # Calculate prediction agreement
                prediction_diff = abs(rf_pred - xgb_pred)
                max_possible_diff = 100  # Maximum possible difference in safety score
                agreement = 1 - (prediction_diff / max_possible_diff)
                
                # Calculate confidence based on agreement and feature coverage
                confidence = (agreement * 0.7 + feature_coverage * 0.3) * 100
            except Exception as e:
                print(f"Error calculating agreement-based confidence: {str(e)}")
                # Fallback to feature coverage only
                confidence = feature_coverage * 80  # Scale to 0-80 range
        else:
            # If only one model is available, base confidence mostly on feature coverage
            confidence = feature_coverage * 80  # Scale to 0-80 range
        
        return round(confidence, 2)
    
    def calculate_feature_importance(self, feature_names: List[str]):
        """Calculate and store feature importance."""
        if not self.is_trained or len(feature_names) == 0:
            print("Warning: Model not trained or no feature names provided")
            return
            
        # Store feature_names for future reference
        self.feature_names = list(feature_names)
        
        # Initialize importance arrays with zeros
        num_features = len(feature_names)
        rf_importance = np.zeros(num_features)
        xgb_importance = np.zeros(num_features)
        
        # Get feature importance from RF model if available
        if self.rf_model is not None and hasattr(self.rf_model, 'feature_importances_'):
            # Check length matches
            if len(self.rf_model.feature_importances_) == num_features:
                rf_importance = self.rf_model.feature_importances_
            else:
                print(f"Warning: RF feature importance length mismatch: {len(self.rf_model.feature_importances_)} vs {num_features}")
                # Try to use as many values as we can safely
                min_len = min(len(self.rf_model.feature_importances_), num_features)
                rf_importance[:min_len] = self.rf_model.feature_importances_[:min_len]
        else:
            print("Warning: RF model missing or has no feature_importances_ attribute")
            
        # Get feature importance from XGB model if available
        if self.xgb_model is not None and hasattr(self.xgb_model, 'feature_importances_'):
            # Check length matches
            if len(self.xgb_model.feature_importances_) == num_features:
                xgb_importance = self.xgb_model.feature_importances_
            else:
                print(f"Warning: XGB feature importance length mismatch: {len(self.xgb_model.feature_importances_)} vs {num_features}")
                # Try to use as many values as we can safely
                min_len = min(len(self.xgb_model.feature_importances_), num_features)
                xgb_importance[:min_len] = self.xgb_model.feature_importances_[:min_len]
        else:
            print("Warning: XGB model missing or has no feature_importances_ attribute")
        
        # Set default ensemble weights if needed
        if self.ensemble_weights is None:
            if self.rf_model is not None and self.xgb_model is not None:
                self.ensemble_weights = (0.5, 0.5)
            elif self.rf_model is not None:
                self.ensemble_weights = (1.0, 0.0)
            elif self.xgb_model is not None:
                self.ensemble_weights = (0.0, 1.0)
            else:
                self.ensemble_weights = (0.5, 0.5)
                
        # Calculate weighted importance using the ensemble weights
        weighted_importance = (self.ensemble_weights[0] * rf_importance + 
                             self.ensemble_weights[1] * xgb_importance)
        
        self.feature_importance = pd.DataFrame({
            'feature': feature_names,
            'rf_importance': rf_importance,
            'xgb_importance': xgb_importance,
            'weighted_importance': weighted_importance
        }).sort_values('weighted_importance', ascending=False)
    
    def evaluate(self, X_test: pd.DataFrame, y_test: pd.Series) -> Dict:
        """Evaluate the ensemble model performance."""
        if not self.is_trained:
            raise ValueError("Model must be trained before evaluation")
        
        # Make predictions
        y_pred = self.predict(X_test)
        
        # Calculate metrics
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, y_pred)
        
        # Calculate additional metrics
        mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100
        
        # Calculate accuracy within different thresholds
        accuracy_5 = np.mean(np.abs(y_test - y_pred) <= 5) * 100
        accuracy_10 = np.mean(np.abs(y_test - y_pred) <= 10) * 100
        
        metrics = {
            'mae': mae,
            'mse': mse,
            'rmse': rmse,
            'r2': r2,
            'mape': mape,
            'accuracy_5': accuracy_5,
            'accuracy_10': accuracy_10
        }
        
        print("Model Evaluation Results:")
        print(f"MAE: {mae:.4f}")
        print(f"RMSE: {rmse:.4f}")
        print(f"R²: {r2:.4f}")
        print(f"MAPE: {mape:.2f}%")
        print(f"Accuracy (±5): {accuracy_5:.2f}%")
        print(f"Accuracy (±10): {accuracy_10:.2f}%")
        
        return metrics
    
    def cross_validate(self, X: pd.DataFrame, y: pd.Series, cv: int = 5) -> Dict:
        """Perform cross-validation."""
        print(f"Performing {cv}-fold cross-validation...")
        
        # Cross-validation for Random Forest
        rf_scores = cross_val_score(self.create_random_forest_model(), X, y, 
                                  cv=cv, scoring='neg_mean_absolute_error')
        rf_mae = -rf_scores.mean()
        rf_std = rf_scores.std()
        
        # Cross-validation for XGBoost
        xgb_scores = cross_val_score(self.create_xgboost_model(), X, y, 
                                   cv=cv, scoring='neg_mean_absolute_error')
        xgb_mae = -xgb_scores.mean()
        xgb_std = xgb_scores.std()
        
        print(f"Random Forest CV MAE: {rf_mae:.4f} (±{rf_std:.4f})")
        print(f"XGBoost CV MAE: {xgb_mae:.4f} (±{xgb_std:.4f})")
        
        return {
            'rf_cv_mae': rf_mae,
            'rf_cv_std': rf_std,
            'xgb_cv_mae': xgb_mae,
            'xgb_cv_std': xgb_std
        }
    
    def save_model(self, filepath: str = 'safety_score_model.pkl'):
        """Save the trained model."""
        if not self.is_trained:
            raise ValueError("Model must be trained before saving")
        
        model_data = {
            'rf_model': self.rf_model,
            'xgb_model': self.xgb_model,
            'ensemble_weights': self.ensemble_weights,
            'feature_importance': self.feature_importance,
            'feature_names': self.feature_names,
            'is_trained': self.is_trained,
            'random_state': self.random_state
        }
        
        joblib.dump(model_data, filepath)
        print(f"Model saved to {filepath}")
    
    def load_model(self, filepath: str = 'safety_score_model.pkl'):
        """Load a trained model."""
        try:
            model_data = joblib.load(filepath)
            print(f"Successfully loaded model from {filepath}")
        except Exception as e:
            print(f"Error loading model: {str(e)}")
            raise ValueError(f"Failed to load model from {filepath}: {str(e)}")

        # Support both dict and sequence formats in case the model was saved
        # using different conventions. If a list/tuple is encountered, attempt
        # to map expected fields by position.
        if isinstance(model_data, (list, tuple)):
            try:
                # Heuristic positional mapping
                self.rf_model = model_data[0] if len(model_data) > 0 else None
                self.xgb_model = model_data[1] if len(model_data) > 1 else None
                self.ensemble_weights = model_data[2] if len(model_data) > 2 else None
                self.feature_importance = model_data[3] if len(model_data) > 3 else None
                self.is_trained = model_data[4] if len(model_data) > 4 else True
                self.random_state = model_data[5] if len(model_data) > 5 else self.random_state
            except Exception as e:
                print(f"Warning during sequence-based model loading: {e}")
                # Continue with partial state rather than failing
        elif isinstance(model_data, dict):
            # Preferred format: dictionary with named keys
            self.rf_model = model_data.get('rf_model')
            self.xgb_model = model_data.get('xgb_model')
            self.ensemble_weights = model_data.get('ensemble_weights')
            self.feature_importance = model_data.get('feature_importance')
            self.feature_names = model_data.get('feature_names', None)
            # If not present, try to infer from feature_importance
            if not self.feature_names and self.feature_importance is not None:
                try:
                    if hasattr(self.feature_importance, 'columns') and 'feature' in self.feature_importance.columns:
                        self.feature_names = self.feature_importance['feature'].tolist()
                except Exception:
                    self.feature_names = None
            self.is_trained = model_data.get('is_trained', True)  # Default to True if not specified
            self.random_state = model_data.get('random_state', self.random_state)
        else:
            # If model_data is a direct model object with predict method
            if hasattr(model_data, 'predict'):
                print("Loaded data appears to be a direct model object")
                self.rf_model = model_data
                self.xgb_model = None
                self.ensemble_weights = (1.0, 0.0)  # Only use RF model
                self.is_trained = True
            else:
                print(f"Warning: Unsupported model_data type: {type(model_data)}")
                raise ValueError(f"Unsupported model_data type loaded from file: {type(model_data)}")
        
        # Ensure we have at least one model and set appropriate ensemble weights
        if self.rf_model is None and self.xgb_model is None:
            print("Warning: Neither rf_model nor xgb_model were loaded successfully")
            raise ValueError("Failed to load any valid models from file")
            
        if self.ensemble_weights is None:
            # Set default weights based on which models are available
            if self.rf_model is not None and self.xgb_model is not None:
                self.ensemble_weights = (0.5, 0.5)
                print("Using default ensemble weights (0.5, 0.5)")
            elif self.rf_model is not None:
                self.ensemble_weights = (1.0, 0.0)
                print("Using only Random Forest model (weights: 1.0, 0.0)")
            elif self.xgb_model is not None:
                self.ensemble_weights = (0.0, 1.0)
                print("Using only XGBoost model (weights: 0.0, 1.0)")
                
        # Set is_trained to True if we have at least one model
        if not self.is_trained and (self.rf_model is not None or self.xgb_model is not None):
            self.is_trained = True
            
        print(f"Model loaded successfully. RF model: {'Present' if self.rf_model else 'Missing'}, " 
              f"XGB model: {'Present' if self.xgb_model else 'Missing'}, "
              f"Weights: {self.ensemble_weights}")

        print(f"Model loaded from {filepath}")
    
    def validate_feature_set(self, X: pd.DataFrame) -> Dict:
        """Validate that the feature set matches the schema structure."""
        # Expected features based on the schema
        expected_schema_features = [
            # Core identification
            'tourist_id', 'timestamp',
            
            # Location data
            'latitude', 'longitude', 'location_name', 'state',
            
            # Temporal features
            'hour', 'is_night', 'month',
            
            # Location and movement features
            'speed_kmh', 'time_since_last_checkin', 'location_risk_level', 'zone_risk_score',
            
            # Weather and environmental features
            'weather_condition', 'weather_safety_impact', 'visibility_score', 'temperature', 'humidity',
            
            # Tourist profile features
            'tourist_profile', 'has_medical_condition',
            
            # Environmental context
            'tourist_density', 'local_event_risk',
            
            # Behavioral features
            'communication_events',
            
            # Target variable
            'safety_score', 'safety_score_category'
        ]
        
        missing_schema_features = [f for f in expected_schema_features if f not in X.columns]
        extra_features = [f for f in X.columns if f not in expected_schema_features]
        
        validation_result = {
            'is_valid': len(missing_schema_features) == 0,
            'missing_schema_features': missing_schema_features,
            'extra_features': extra_features,
            'total_features': len(X.columns),
            'schema_features_present': len(expected_schema_features) - len(missing_schema_features),
            'schema_completeness': (len(expected_schema_features) - len(missing_schema_features)) / len(expected_schema_features) * 100
        }
        
        if validation_result['is_valid']:
            print("✅ Schema validation passed - all schema features present")
        else:
            print(f"⚠️ Schema validation warning - missing schema features: {missing_schema_features}")
            print(f"Schema completeness: {validation_result['schema_completeness']:.1f}%")
        
        return validation_result
    
    def create_sample_record(self) -> Dict:
        """Create a sample record that matches the schema exactly."""
        import random
        from datetime import datetime
        
        # Sample locations from Northeast India
        locations = [
            {'name': 'Agartala', 'state': 'Tripura', 'lat': 23.8315, 'lon': 91.2862, 'risk': 'low'},
            {'name': 'Shillong', 'state': 'Meghalaya', 'lat': 25.5788, 'lon': 91.8933, 'risk': 'medium'},
            {'name': 'Kohima', 'state': 'Nagaland', 'lat': 25.6751, 'lon': 94.1106, 'risk': 'medium'},
            {'name': 'Aizawl', 'state': 'Mizoram', 'lat': 23.7271, 'lon': 92.7176, 'risk': 'low'},
            {'name': 'Kaziranga', 'state': 'Assam', 'lat': 26.5924, 'lon': 93.1650, 'risk': 'high'},
            {'name': 'Guwahati', 'state': 'Assam', 'lat': 26.1445, 'lon': 91.7362, 'risk': 'medium'},
            {'name': 'Imphal', 'state': 'Manipur', 'lat': 24.8170, 'lon': 93.9368, 'risk': 'high'},
            {'name': 'Itanagar', 'state': 'Arunachal Pradesh', 'lat': 27.0844, 'lon': 93.6053, 'risk': 'medium'}
        ]
        
        # Risk level mappings
        risk_levels = {'low': 0.2, 'medium': 0.5, 'high': 0.8}
        
        # Weather conditions
        weather_conditions = ['clear', 'light_rain', 'heavy_rain', 'storm', 'fog', 'snow']
        weather_impacts = {'clear': 0.1, 'light_rain': 0.3, 'heavy_rain': 0.6, 'storm': 0.8, 'fog': 0.7, 'snow': 0.9}
        visibility_scores = {'clear': 1.0, 'light_rain': 0.8, 'heavy_rain': 0.4, 'storm': 0.2, 'fog': 0.3, 'snow': 0.5}
        
        # Tourist profiles
        profiles = ['beginner', 'moderate', 'experienced', 'adventure_seeker']
        
        # Select random location
        location = random.choice(locations)
        weather = random.choice(weather_conditions)
        profile = random.choice(profiles)
        
        # Generate timestamp
        timestamp = datetime.now()
        hour = random.randint(0, 23)
        
        # Create sample record matching schema
        sample_record = {
            'tourist_id': f'tourist_{random.randint(1000, 9999)}',
            'timestamp': timestamp,
            'latitude': location['lat'] + random.uniform(-0.01, 0.01),
            'longitude': location['lon'] + random.uniform(-0.01, 0.01),
            'location_name': location['name'],
            'state': location['state'],
            'hour': hour,
            'is_night': hour < 6 or hour > 20,
            'month': timestamp.month,
            
            # Location and movement features
            'speed_kmh': random.uniform(0, 50),
            'time_since_last_checkin': random.randint(5, 120),
            'location_risk_level': location['risk'],
            'zone_risk_score': risk_levels[location['risk']],
            
            # Weather and environmental features
            'weather_condition': weather,
            'weather_safety_impact': weather_impacts[weather],
            'visibility_score': visibility_scores[weather],
            'temperature': random.uniform(15, 35),
            'humidity': random.uniform(40, 90),
            
            # Tourist profile features
            'tourist_profile': profile,
            'has_medical_condition': random.choice([True, False]),
            
            # Environmental context
            'tourist_density': random.randint(10, 100),
            'local_event_risk': random.uniform(0, 1),
            
            # Behavioral features
            'communication_events': random.randint(0, 10),
            
            # Target variable (will be predicted)
            'safety_score': random.uniform(20, 90),
            'safety_score_category': random.choice(['Very Safe', 'Safe', 'Moderate Risk', 'High Risk', 'Very High Risk'])
        }
        
        return sample_record
    
    def save_schema_template(self, filepath: str = 'safety_score_schema.json'):
        """Save the schema template as a proper JSON file."""
        import json
        
        schema_template = {
            "description": "Safety Score Prediction Schema - Simplified Record Structure",
            "version": "1.0",
            "fields": {
                "tourist_id": {
                    "type": "string",
                    "description": "Unique tourist identifier",
                    "example": "tourist_1234"
                },
                "timestamp": {
                    "type": "datetime",
                    "description": "Record timestamp",
                    "example": "2024-01-15T10:30:00"
                },
                "latitude": {
                    "type": "float",
                    "description": "Current latitude coordinate",
                    "example": 23.8315
                },
                "longitude": {
                    "type": "float", 
                    "description": "Current longitude coordinate",
                    "example": 91.2862
                },
                "location_name": {
                    "type": "string",
                    "description": "Name of the location",
                    "example": "Agartala"
                },
                "state": {
                    "type": "string",
                    "description": "State name",
                    "example": "Tripura"
                },
                "hour": {
                    "type": "integer",
                    "description": "Hour of day (0-23)",
                    "example": 14
                },
                "is_night": {
                    "type": "boolean",
                    "description": "Whether it's night time",
                    "example": False
                },
                "month": {
                    "type": "integer",
                    "description": "Month of year (1-12)",
                    "example": 6
                },
                "speed_kmh": {
                    "type": "float",
                    "description": "Current speed in km/h",
                    "example": 15.5
                },
                "time_since_last_checkin": {
                    "type": "integer",
                    "description": "Minutes since last check-in",
                    "example": 30
                },
                "location_risk_level": {
                    "type": "string",
                    "description": "Risk level of location",
                    "enum": ["low", "medium", "high"],
                    "example": "medium"
                },
                "zone_risk_score": {
                    "type": "float",
                    "description": "Numeric risk score (0-1)",
                    "example": 0.5
                },
                "weather_condition": {
                    "type": "string",
                    "description": "Current weather condition",
                    "enum": ["clear", "light_rain", "heavy_rain", "storm", "fog", "snow"],
                    "example": "clear"
                },
                "weather_safety_impact": {
                    "type": "float",
                    "description": "Weather safety impact score (0-1)",
                    "example": 0.3
                },
                "visibility_score": {
                    "type": "float",
                    "description": "Visibility score (0-1)",
                    "example": 0.8
                },
                "temperature": {
                    "type": "float",
                    "description": "Temperature in Celsius",
                    "example": 25.0
                },
                "humidity": {
                    "type": "float",
                    "description": "Humidity percentage",
                    "example": 60.0
                },
                "tourist_profile": {
                    "type": "string",
                    "description": "Tourist profile type",
                    "enum": ["beginner", "moderate", "experienced", "adventure_seeker"],
                    "example": "moderate"
                },
                "has_medical_condition": {
                    "type": "boolean",
                    "description": "Whether tourist has medical condition",
                    "example": False
                },
                "tourist_density": {
                    "type": "integer",
                    "description": "Tourist density in area (0-100)",
                    "example": 50
                },
                "local_event_risk": {
                    "type": "float",
                    "description": "Local event risk score (0-1)",
                    "example": 0.2
                },
                "communication_events": {
                    "type": "integer",
                    "description": "Number of communication events",
                    "example": 3
                },
                "safety_score": {
                    "type": "float",
                    "description": "Predicted safety score (0-100)",
                    "example": 75.5
                },
                "safety_score_category": {
                    "type": "string",
                    "description": "Safety score category",
                    "enum": ["Very Safe", "Safe", "Moderate Risk", "High Risk", "Very High Risk"],
                    "example": "Safe"
                }
            }
        }
        
        with open(filepath, 'w') as f:
            json.dump(schema_template, f, indent=2)
        
        print(f"Schema template saved to {filepath}")
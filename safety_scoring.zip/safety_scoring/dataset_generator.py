"""
Safety Score Prediction Dataset Generator

This module generates a comprehensive synthetic dataset for training the Safety Score Prediction Engine.
The dataset includes all required features as specified in the ml_model_docs.md requirements.
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
from typing import List, Dict, Tuple
import json

class SafetyScoreDatasetGenerator:
    """Generates synthetic dataset for Safety Score Prediction Engine."""
    
    def __init__(self, random_seed: int = 42):
        """Initialize the dataset generator with random seed."""
        np.random.seed(random_seed)
        random.seed(random_seed)
        
        # Define Northeast India locations with risk classifications
        self.locations = {
            'Agartala': {'lat': 23.8315, 'lon': 91.2862, 'risk_level': 'low', 'state': 'Tripura'},
            'Shillong': {'lat': 25.5788, 'lon': 91.8933, 'risk_level': 'medium', 'state': 'Meghalaya'},
            'Kohima': {'lat': 25.6751, 'lon': 94.1106, 'risk_level': 'medium', 'state': 'Nagaland'},
            'Aizawl': {'lat': 23.7271, 'lon': 92.7176, 'risk_level': 'low', 'state': 'Mizoram'},
            'Kaziranga': {'lat': 26.5924, 'lon': 93.1650, 'risk_level': 'high', 'state': 'Assam'},
            'Guwahati': {'lat': 26.1445, 'lon': 91.7362, 'risk_level': 'medium', 'state': 'Assam'},
            'Imphal': {'lat': 24.8170, 'lon': 93.9368, 'risk_level': 'high', 'state': 'Manipur'},
            'Itanagar': {'lat': 27.0844, 'lon': 93.6053, 'risk_level': 'medium', 'state': 'Arunachal Pradesh'}
        }
        
        # Weather conditions with safety impact
        self.weather_conditions = {
            'clear': {'safety_impact': 0.1, 'visibility': 1.0},
            'light_rain': {'safety_impact': 0.3, 'visibility': 0.8},
            'heavy_rain': {'safety_impact': 0.6, 'visibility': 0.4},
            'storm': {'safety_impact': 0.8, 'visibility': 0.2},
            'fog': {'safety_impact': 0.7, 'visibility': 0.3},
            'snow': {'safety_impact': 0.9, 'visibility': 0.5}
        }
        
        # Risk level mappings
        self.risk_levels = {'low': 0.2, 'medium': 0.5, 'high': 0.8}
        
        # Tourist profiles
        self.tourist_profiles = {
            'experienced': {'risk_tolerance': 0.3, 'safety_awareness': 0.8},
            'moderate': {'risk_tolerance': 0.5, 'safety_awareness': 0.6},
            'beginner': {'risk_tolerance': 0.7, 'safety_awareness': 0.4},
            'adventure_seeker': {'risk_tolerance': 0.9, 'safety_awareness': 0.3}
        }

    def generate_tourist_data(self, num_tourists: int = 1000, days: int = 30) -> pd.DataFrame:
        """Generate comprehensive tourist safety data."""
        data = []
        
        for tourist_id in range(num_tourists):
            # Generate tourist profile
            profile = random.choice(list(self.tourist_profiles.keys()))
            group_size = random.choice([1, 2, 3, 4, 5, 6, 8, 10])
            has_medical_condition = random.random() < 0.15
            previous_incidents = random.randint(0, 3)
            
            # Generate time series data
            start_date = datetime.now() - timedelta(days=days)
            
            for day in range(days):
                for hour in range(0, 24, 2):  # Every 2 hours
                    timestamp = start_date + timedelta(days=day, hours=hour)
                    
                    # Select location
                    location_name = random.choice(list(self.locations.keys()))
                    location_data = self.locations[location_name]
                    
                    # Generate movement data
                    base_lat = location_data['lat'] + np.random.normal(0, 0.01)
                    base_lon = location_data['lon'] + np.random.normal(0, 0.01)
                    
                    # Generate weather
                    weather = random.choice(list(self.weather_conditions.keys()))
                    weather_data = self.weather_conditions[weather]
                    
                    # Calculate safety score components
                    safety_score = self._calculate_safety_score(
                        location_data, weather_data, profile, group_size,
                        has_medical_condition, previous_incidents, hour, day
                    )
                    
                    # Generate additional features
                    tourist_density = self._generate_tourist_density(location_name, hour, day)
                    local_event_risk = self._generate_event_risk(day, hour)
                    
                    # Generate behavioral features
                    communication_events = random.randint(0, 5)
                    
                    # Generate movement features
                    speed_kmh = random.uniform(0, 50)
                    time_since_last_checkin = random.randint(5, 120)
                    
                    record = {
                        'tourist_id': f'tourist_{tourist_id}',
                        'timestamp': timestamp,
                        'latitude': base_lat,
                        'longitude': base_lon,
                        'location_name': location_name,
                        'state': location_data['state'],
                        'hour': hour,
                        'is_night': hour < 6 or hour > 20,
                        'month': timestamp.month,
                        
                        # Location and movement features
                        'speed_kmh': speed_kmh,
                        'time_since_last_checkin': time_since_last_checkin,
                        'location_risk_level': location_data['risk_level'],
                        'zone_risk_score': self.risk_levels[location_data['risk_level']],
                        
                        # Weather and environmental features
                        'weather_condition': weather,
                        'weather_safety_impact': weather_data['safety_impact'],
                        'visibility_score': weather_data['visibility'],
                        'temperature': random.uniform(15, 35),
                        'humidity': random.uniform(40, 90),
                        
                        # Tourist profile features
                        'tourist_profile': profile,
                        'has_medical_condition': has_medical_condition,
                        
                        # Environmental context
                        'tourist_density': tourist_density,
                        'local_event_risk': local_event_risk,
                        
                        # Behavioral features
                        'communication_events': communication_events,
                        # Target variable
                        'safety_score': safety_score,
                        'safety_score_category': self._categorize_safety_score(safety_score)
                    }
                    
                    data.append(record)
        
        return pd.DataFrame(data)
    
    def _calculate_safety_score(self, location_data: Dict, weather_data: Dict, 
                              profile: str, group_size: int, has_medical_condition: bool,
                              previous_incidents: int, hour: int, day: int) -> float:
        """Calculate safety score based on multiple factors."""
        
        # Base score
        base_score = 70.0
        
        # Location risk impact
        location_risk = self.risk_levels[location_data['risk_level']]
        location_impact = (1 - location_risk) * 20  # 0-20 points
        
        # Weather impact
        weather_impact = (1 - weather_data['safety_impact']) * 15  # 0-15 points
        
        # Time-based factors
        time_impact = 10 if 6 <= hour <= 20 else 5  # Day vs night
        
        # Tourist profile impact (simplified)
        profile_impact = 5  # Fixed impact for simplicity
        
        # Group size impact (safety in numbers)
        group_impact = min(group_size * 2, 10)  # 0-10 points
        
        # Medical condition impact
        medical_impact = -5 if has_medical_condition else 0
        
        # Previous incidents impact
        incident_impact = -previous_incidents * 3  # -0 to -9 points
        
        # Calculate final score
        safety_score = base_score + location_impact + weather_impact + time_impact + \
                      profile_impact + group_impact + medical_impact + incident_impact
        
        # Ensure score is between 0 and 100
        safety_score = max(0, min(100, safety_score))
        
        # Add some randomness for realism
        safety_score += np.random.normal(0, 2)
        safety_score = max(0, min(100, safety_score))
        
        return round(safety_score, 2)
    
    def _categorize_safety_score(self, score: float) -> str:
        """Categorize safety score into risk levels."""
        if score >= 80:
            return 'very_safe'
        elif score >= 60:
            return 'safe'
        elif score >= 40:
            return 'moderate_risk'
        elif score >= 20:
            return 'high_risk'
        else:
            return 'very_high_risk'
    
    def _generate_tourist_density(self, location: str, hour: int, day: int) -> int:
        """Generate tourist density based on location, time, and day."""
        base_density = random.randint(10, 100)
        
        # Peak hours (10-18)
        if 10 <= hour <= 18:
            base_density *= 1.5
        
        # Weekend effect
        if day % 7 >= 5:  # Weekend
            base_density *= 1.3
        
        # Popular locations
        popular_locations = ['Kaziranga', 'Shillong', 'Guwahati']
        if location in popular_locations:
            base_density *= 1.2
        
        return min(int(base_density), 100)
    
    def _generate_event_risk(self, day: int, hour: int) -> float:
        """Generate local event risk score."""
        base_risk = random.uniform(0, 0.5)
        
        # Festival season (simulated)
        if day % 30 < 5:  # Festival period
            base_risk += 0.3
        
        # Evening events
        if 18 <= hour <= 22:
            base_risk += 0.2
        
        return min(base_risk, 1.0)
    
    def _generate_infrastructure_quality(self, location: str) -> float:
        """Generate infrastructure quality score for location."""
        # Base infrastructure quality
        base_quality = random.uniform(0.6, 0.9)
        
        # Urban areas have better infrastructure
        urban_locations = ['Agartala', 'Guwahati', 'Shillong']
        if location in urban_locations:
            base_quality += 0.1
        
        return min(base_quality, 1.0)
    
    def save_dataset(self, df: pd.DataFrame, filename: str = 'safety_score_dataset.csv'):
        """Save dataset to CSV file."""
        df.to_csv(filename, index=False)
        print(f"Dataset saved to {filename}")
        print(f"Dataset shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")
        
        # Save dataset statistics
        stats = {
            'total_records': len(df),
            'unique_tourists': df['tourist_id'].nunique(),
            'date_range': {
                'start': df['timestamp'].min().isoformat(),
                'end': df['timestamp'].max().isoformat()
            },
            'safety_score_stats': {
                'mean': df['safety_score'].mean(),
                'std': df['safety_score'].std(),
                'min': df['safety_score'].min(),
                'max': df['safety_score'].max()
            },
            'safety_categories': df['safety_score_category'].value_counts().to_dict(),
            'locations': df['location_name'].value_counts().to_dict(),
            'weather_conditions': df['weather_condition'].value_counts().to_dict()
        }
        
        with open('safety_score_dataset_stats.json', 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"Dataset statistics saved to safety_score_dataset_stats.json")
        return stats

def main():
    """Generate the safety score prediction dataset."""
    print("Generating Safety Score Prediction Dataset...")
    
    generator = SafetyScoreDatasetGenerator(random_seed=42)
    
    # Generate dataset
    df = generator.generate_tourist_data(num_tourists=500, days=14)
    
    # Save dataset
    stats = generator.save_dataset(df, 'safety_score_dataset.csv')
    
    print("\nDataset Generation Complete!")
    print(f"Generated {len(df)} records for {df['tourist_id'].nunique()} tourists")
    print(f"Safety score range: {df['safety_score'].min():.2f} - {df['safety_score'].max():.2f}")
    print(f"Safety category distribution:")
    for category, count in df['safety_score_category'].value_counts().items():
        print(f"  {category}: {count/len(df):.2%}")

if __name__ == "__main__":
    main()

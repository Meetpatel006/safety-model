# Safety Score Prediction Engine

A comprehensive machine learning system for real-time safety score prediction for tourists in Northeast India, built as part of the Smart Tourist Safety Monitoring & Incident Response System.

## 🎯 Overview

The Safety Score Prediction Engine calculates dynamic safety scores (0-100) for tourists in real-time using a Random Forest + XGBoost ensemble model. It integrates multiple data sources including location data, weather conditions, tourist profiles, behavioral patterns, and environmental factors to provide accurate safety assessments.

## 🏗️ Architecture

### Core Components

1. **Dataset Generation** (`dataset_generator.py`)
   - Includes location, weather, tourist profile, behavioral, and environmental data
   - Configurable parameters for tourists, days, and data complexity

2. **Safety Score Model** (`safety_score_model.py`)

4. **Training Pipeline** (`train_safety_model.py`)
   - Complete end-to-end training pipeline
   - Cross-validation and model evaluation
   - Artifact saving and model persistence

5. **FastAPI Service** (`api.py`)
   - REST API for real-time predictions
   - Single and batch prediction endpoints
   - Health monitoring and model information

6. **Test Suite** (`test_safety_system.py`)
   - Comprehensive testing framework
   - Unit tests, integration tests, and performance tests
   - API endpoint testing

## 🚀 Quick Start

### Prerequisites

```bash
pip install -r requirements.txt
```

### 1. Generate Dataset

```python
from dataset_generator import SafetyScoreDatasetGenerator

# Generate dataset
generator = SafetyScoreDatasetGenerator(random_seed=42)
df = generator.generate_tourist_data(num_tourists=1000, days=30)

# Save dataset
generator.save_dataset(df, 'safety_score_dataset.csv')
```

### 2. Train Model

```python
from train_safety_model import SafetyScoreTrainingPipeline

# Configure training
config = {
    'num_tourists': 1000,
    'num_days': 30,
    'num_features': 50,
    'output_dir': 'safety_scoring_models'
}

# Run training pipeline
pipeline = SafetyScoreTrainingPipeline(config)
results = pipeline.run_training_pipeline()
```

### 3. Start API Server

```bash
cd safety_scoring
python api.py
```

The API will be available at `http://localhost:8000`

### 4. Make Predictions

```python
import requests

# Single prediction
response = requests.post("http://localhost:8000/predict", json={
    "location": {
        "latitude": 23.8315,
        "longitude": 91.2862,
        "location_name": "Agartala",
        "state": "Tripura"
    },
    "weather": {
        "condition": "clear",
        "temperature": 25.0,
        "humidity": 60.0,
        "visibility": 1.0
    },
    "tourist": {
        "tourist_id": "tourist_123",
        "profile_type": "moderate",
        "has_medical_condition": False
    },
    "behavioral": {
        "communication_events": 2,
        "speed_kmh": 10.0
    },
    "environmental": {
        "tourist_density": 50,
        "local_event_risk": 0.2
    }
})

prediction = response.json()
print(f"Safety Score: {prediction['safety_score']}")
print(f"Category: {prediction['safety_category']}")
print(f"Recommendations: {prediction['recommendations']}")
```

## 📊 Features

### Input Features

#### Location Data
- Current coordinates (latitude, longitude)
- Location name and state
- Zone risk classifications

#### Temporal Features
- Time of day (hour)
- Month and season
- Night/day indicators

#### Tourist Profile
- Tourist profile type (beginner, moderate, experienced, adventure_seeker)
- Medical conditions

#### Environmental Data
- Weather conditions and visibility
- Tourist density in area
- Local event risk

#### Behavioral Data
- Communication frequency
- Movement patterns (speed)

### Output

- **Safety Score** (0-100): Numerical safety assessment
- **Safety Category**: Categorical risk level
- **Contributing Factors**: Top factors influencing the score
- **Recommendations**: Actionable safety advice
- **Confidence**: Prediction confidence score

## 🔧 Configuration

### Training Configuration

```python
config = {
    'random_seed': 42,
    'num_tourists': 1000,           # Number of tourists in dataset
    'num_days': 30,                 # Number of days to simulate
    'test_size': 0.2,               # Test set size
    'validation_size': 0.2,         # Validation set size
    'feature_selection_method': 'random_forest',
    'num_features': 50,             # Number of features to select
    'cross_validation_folds': 5,    # CV folds
    'save_artifacts': True,         # Save model artifacts
    'output_dir': 'safety_scoring_models'
}
```

### Model Parameters

#### Random Forest
- `n_estimators`: 200
- `max_depth`: 15
- `min_samples_split`: 5
- `min_samples_leaf`: 2
- `max_features`: 'sqrt'

#### XGBoost
- `n_estimators`: 200
- `max_depth`: 8
- `learning_rate`: 0.1
- `subsample`: 0.8
- `colsample_bytree`: 0.8

## 📈 Performance Metrics

### Target Performance
- **Accuracy**: 85%+ score prediction accuracy
- **MAE**: <5 points on 0-100 scale
- **Response Time**: <50ms for real-time scoring
- **R²**: >0.8 for model fit

### Evaluation Metrics
- Mean Absolute Error (MAE)
- Root Mean Square Error (RMSE)
- R-squared (R²)
- Mean Absolute Percentage Error (MAPE)
- Accuracy within ±5 and ±10 points

## 🧪 Testing

Run the comprehensive test suite:

```bash
python test_safety_system.py
```

The test suite includes:
- Dataset generation tests
- Feature engineering tests
- Model training tests
- API endpoint tests
- Performance tests
- Data quality tests

## 📚 API Documentation

### Endpoints

#### Health Check
```
GET /health
```

#### Single Prediction
```
POST /predict
```

#### Batch Prediction
```
POST /predict/batch
```

#### Model Information
```
GET /model/info
```

#### Feature Importance
```
GET /model/features
```

### Request/Response Examples

See the API documentation at `http://localhost:8000/docs` when the server is running.

## 🔍 Model Interpretability

The model provides interpretable results through:

1. **Feature Importance**: Shows which features contribute most to predictions
2. **Contributing Factors**: Lists top factors for each prediction
3. **Ensemble Weights**: Shows how Random Forest and XGBoost are weighted
4. **Confidence Scores**: Indicates prediction reliability

## 🚀 Deployment

### Docker Deployment

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["python", "api.py"]
```

### Production Considerations

1. **Model Versioning**: Use MLflow or similar for model versioning
2. **Monitoring**: Implement model performance monitoring
3. **Scaling**: Use load balancers for high availability
4. **Caching**: Implement Redis for prediction caching
5. **Security**: Add authentication and rate limiting

## 📊 Monitoring

### Key Metrics to Monitor

1. **Model Performance**
   - Prediction accuracy
   - Response time
   - Error rates

2. **System Health**
   - API availability
   - Memory usage
   - CPU utilization

3. **Business Metrics**
   - Prediction volume
   - User satisfaction
   - Safety incident correlation

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is part of the Smart Tourist Safety Monitoring & Incident Response System for SIH25002.

## 🆘 Support

For issues and questions:
1. Check the test suite results
2. Review the API documentation
3. Check the model performance metrics
4. Contact the development team

## 🔮 Future Enhancements

1. **Real-time Learning**: Implement online learning for model updates
2. **Multi-modal Input**: Add image and audio processing
3. **Federated Learning**: Privacy-preserving model training
4. **Edge Deployment**: Deploy models on edge devices
5. **Advanced Analytics**: Add time series forecasting and anomaly detection

"""
Modal Training Script for Safety Score Model
"""

import modal
import os
from pathlib import Path

# Create a Modal app
app = modal.App("safety-score-training")

root = Path(__file__).parent
training_image = (
    modal.Image.debian_slim()
    .pip_install(
        "scikit-learn>=1.2.0",
        "xgboost>=1.7.0",
        "numpy>=1.23.0",
        "pandas>=1.5.0",
        "joblib>=1.2.0",
        "python-dateutil>=2.8.0",
        "scipy>=1.10.0",
    )
    .add_local_dir(root, remote_path="/root")
)

volume = modal.Volume.from_name("safety-scoring-volume", create_if_missing=True)

MODEL_DIR = "/root/safety_scoring/models"


@app.function(
    image=training_image,
    volumes={"/root/safety_scoring": volume},
    timeout=1800,
)
def train_model():
    """Train the safety score model and save artifacts."""
    import pandas as pd
    import numpy as np
    import joblib
    import json
    import sys
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import OneHotEncoder, StandardScaler
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.metrics import mean_absolute_error, r2_score
    
    # Set up directory
    os.makedirs(MODEL_DIR, exist_ok=True)
    
    # Print environment information for debugging
    print(f"Python version: {sys.version}")
    print(f"Current directory: {os.getcwd()}")
    print(f"Directory contents: {os.listdir('.')}")
    print(f"Root directory contents: {os.listdir('/root')}")
    
    try:
        # Import the necessary module
        print("Importing SafetyScoreTrainingPipeline from train_safety_model...")
        from train_safety_model import SafetyScoreTrainingPipeline
        
        # Generate a simple dataset as a fallback
        print("Generating simple dataset for testing...")
        test_df = pd.DataFrame({
            'timestamp': pd.date_range(start='2025-08-27', periods=100, freq='H'),
            'safety_score': np.random.uniform(70, 100, 100),
            'location_name': ['Test Location'] * 100,
            'tourist_id': [f'T{i}' for i in range(100)]
        })
        
        # Save the test dataset stats
        test_df.describe().to_json(f"{MODEL_DIR}/simple_dataset_stats.json")
        print(f"Simple dataset stats saved to {MODEL_DIR}/simple_dataset_stats.json")
        
        # Try to use the training pipeline
        print("Attempting to use SafetyScoreTrainingPipeline...")
        pipeline = SafetyScoreTrainingPipeline()
        dataset = pipeline.generate_dataset()
        
        # Fix the safety_score_category format to match schema validation requirements
        print("Fixing safety_score_category format...")
        category_mapping = {
            'very_safe': 'Very Safe',
            'safe': 'Safe',
            'moderate_risk': 'Moderate Risk',
            'high_risk': 'High Risk',
            'very_high_risk': 'Very High Risk'
        }
        if 'safety_score_category' in dataset.columns:
            dataset['safety_score_category'] = dataset['safety_score_category'].map(category_mapping)
            print("Safety categories successfully mapped to expected format")
        
        # Save the actual dataset stats
        dataset.describe().to_json(f"{MODEL_DIR}/dataset_stats.json")
        print(f"Full dataset stats saved to {MODEL_DIR}/dataset_stats.json")
        
        # Try running the pipeline but with proper encoding of categorical features first
        print("Preparing dataset according to the schema requirements...")
        
        # Define encoders for categorical features based on schema
        categorical_mappings = {
            'location_risk_level': {'low': 0, 'medium': 1, 'high': 2},
            'weather_condition': {'clear': 0, 'light_rain': 1, 'heavy_rain': 2, 'storm': 3, 'fog': 4, 'snow': 5},
            'tourist_profile': {'beginner': 0, 'moderate': 1, 'experienced': 2, 'adventure_seeker': 3}
        }
        
        # Create a copy of the dataset for preprocessing
        processed_df = dataset.copy()
        
        # Apply mappings to categorical features
        for col, mapping in categorical_mappings.items():
            if col in processed_df.columns:
                print(f"Mapping {col} to numeric values using: {mapping}")
                # Overwrite original categorical column with numeric mapping
                processed_df[col] = processed_df[col].map(mapping).fillna(0).astype(int)
        
        # Ensure safety_score_category follows schema requirements
        print("Verifying safety_score_category meets schema requirements...")
        expected_categories = ['Very Safe', 'Safe', 'Moderate Risk', 'High Risk', 'Very High Risk']
        if 'safety_score_category' in processed_df.columns:
            cat_counts = processed_df['safety_score_category'].value_counts()
            print(f"Current safety categories: {cat_counts.index.tolist()}")
            print(f"Expected categories: {expected_categories}")
            
            # Check if all categories are as expected
            if set(cat_counts.index) == set(expected_categories):
                print("✓ Safety categories match schema requirements")
            else:
                print("⚠️ Safety categories don't match schema requirements")
        
        # Now try to run the training pipeline with the fixed dataset
        print("Attempting to use the training pipeline with the processed dataset...")
        
        try:
            print("Running training pipeline directly...")
            results = pipeline.run_training_pipeline()
            print("Training pipeline completed with results:", results.get('status', 'unknown'))
            
            # Check if the training failed and needs fallback
            if isinstance(results, dict) and results.get('status') != 'success':
                raise Exception(f"Training failed: {results.get('error', 'Unknown error')}")
            
        except Exception as e:
            print(f"Training pipeline failed with error: {str(e)}")
            
            # Fallback to simpler model if pipeline fails
            print("Falling back to simplified model training...")
            
            # Function to train a simplified model that respects the schema
            def train_schema_compliant_model(df):
                print("Training schema-compliant model...")
                
                # Create a copy to avoid modifying the original
                working_df = df.copy()
                
                # Handle categorical features according to schema
                if 'location_risk_level' in working_df.columns:
                    # Map categorical to numeric in-place
                    working_df['location_risk_level'] = working_df['location_risk_level'].map({'low': 0, 'medium': 1, 'high': 2}).fillna(0).astype(int)

                if 'weather_condition' in working_df.columns:
                    working_df['weather_condition'] = working_df['weather_condition'].map({'clear': 0, 'light_rain': 1, 'heavy_rain': 2, 'storm': 3, 'fog': 4, 'snow': 5}).fillna(0).astype(int)

                if 'tourist_profile' in working_df.columns:
                    working_df['tourist_profile'] = working_df['tourist_profile'].map({'beginner': 0, 'moderate': 1, 'experienced': 2, 'adventure_seeker': 3}).fillna(1).astype(int)

                if 'safety_score_category' in working_df.columns:
                    # Optionally map categories to numeric ordinal but keep original column for schema
                    working_df['safety_score_category_numeric'] = working_df['safety_score_category'].map({'Very Safe': 5, 'Safe': 4, 'Moderate Risk': 3, 'High Risk': 2, 'Very High Risk': 1})
                
                # Use all numeric features (categoricals have been mapped to numeric)
                numeric_cols = working_df.select_dtypes(include=[np.number]).columns.tolist()
                
                # Filter out non-feature columns
                excluded_cols = ['tourist_id', 'timestamp', 'safety_score']
                feature_cols = [col for col in numeric_cols if col not in excluded_cols]
                
                print(f"Using {len(feature_cols)} features including encoded categorical features")
                
                # Prepare data
                X = working_df[feature_cols].fillna(0)
                y = working_df['safety_score']
                
                # Split data
                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
                
                # Train model
                model = RandomForestRegressor(n_estimators=100, random_state=42)
                model.fit(X_train, y_train)
                
                # Evaluate
                y_pred = model.predict(X_test)
                mae = mean_absolute_error(y_test, y_pred)
                r2 = r2_score(y_test, y_pred)
                
                print(f"Model trained successfully!")
                print(f"Test MAE: {mae:.4f}")
                print(f"Test R²: {r2:.4f}")
                
                # Save model
                model_path = f"{MODEL_DIR}/safety_score_model.pkl"
                joblib.dump(model, model_path)
                
                # Save feature importance
                feature_importance = pd.DataFrame({
                    'feature': feature_cols,
                    'importance': model.feature_importances_
                }).sort_values('importance', ascending=False)
                feature_importance.to_csv(f"{MODEL_DIR}/feature_importance.csv", index=False)
                
                # Save schema information
                schema_info = {
                    'categorical_features': {
                        'location_risk_level': ['low', 'medium', 'high'],
                        'weather_condition': ['clear', 'light_rain', 'heavy_rain', 'storm', 'fog', 'snow'],
                        'tourist_profile': ['beginner', 'moderate', 'experienced', 'adventure_seeker'],
                        'safety_score_category': ['Very Safe', 'Safe', 'Moderate Risk', 'High Risk', 'Very High Risk']
                    },
                    'numeric_features': [col for col in feature_cols],
                    'categorical_mappings': {
                        'location_risk_level': {'low': 0, 'medium': 1, 'high': 2},
                        'weather_condition': {'clear': 0, 'light_rain': 1, 'heavy_rain': 2, 'storm': 3, 'fog': 4, 'snow': 5},
                        'tourist_profile': {'beginner': 0, 'moderate': 1, 'experienced': 2, 'adventure_seeker': 3},
                        'safety_score_category': {'Very Safe': 5, 'Safe': 4, 'Moderate Risk': 3, 'High Risk': 2, 'Very High Risk': 1}
                    },
                    'target': 'safety_score',
                    'model_type': 'RandomForestRegressor'
                }
                
                # Save schema info
                with open(f"{MODEL_DIR}/schema_info.json", 'w') as f:
                    json.dump(schema_info, f, indent=2)
                
                # Save preprocessing information
                preprocessing_info = {
                    'categorical_columns': ['location_risk_level', 'weather_condition', 'tourist_profile', 'safety_score_category'],
                    'numeric_columns': [col for col in feature_cols],
                    'encoders': {
                        'categorical_mappings': schema_info['categorical_mappings']
                    }
                }
                
                joblib.dump(preprocessing_info, f"{MODEL_DIR}/preprocessing_info.pkl")
                
                return {
                    'status': 'success',
                    'model_path': model_path,
                    'metrics': {
                        'mae': float(mae),
                        'r2': float(r2)
                    },
                    'feature_importance': feature_importance.head(10).to_dict(),
                    'features_used': feature_cols,
                    'schema_info_path': f"{MODEL_DIR}/schema_info.json",
                    'preprocessing_info_path': f"{MODEL_DIR}/preprocessing_info.pkl"
                }
            
            # Train the model with processed dataset
            results = train_schema_compliant_model(processed_df)
        
        # Check if training was successful using the results from our fallback training
        if isinstance(results, dict) and results.get('status') == 'success':
            print("Model training completed successfully!")
            
            # Our fallback training has already saved the model and artifacts
            # We don't need to use the pipeline.model as it wasn't successfully trained
            model_path = results.get('model_path', '')
            if model_path:
                print(f"Model was successfully saved to {model_path}")
            else:
                print("Note: Model path information is missing")
                
            # Print some metrics if available
            if 'metrics' in results:
                print(f"Model performance - MAE: {results['metrics'].get('mae', 'N/A')}, R²: {results['metrics'].get('r2', 'N/A')}")
                
            # Our fallback model has already saved all necessary files
        else:
            print(f"Training failed: {results.get('error', 'Unknown error')}")
        
        # Save metadata about the process regardless of training outcome
        metadata = {
            "timestamp": pd.Timestamp.now().isoformat(),
            "dataset_size": len(dataset),
            "columns": list(dataset.columns),
            "safety_score_range": {
                "min": float(dataset['safety_score'].min()),
                "max": float(dataset['safety_score'].max()),
                "mean": float(dataset['safety_score'].mean())
            },
            "training_status": "success" if isinstance(results, dict) and results.get('status') == 'success' else "failed",
            "message": "Training pipeline executed"
        }
        
        with open(f"{MODEL_DIR}/metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)
        
        return {
            "status": "success",
            "message": "Pipeline execution completed",
            "dataset_size": len(dataset),
            "stats_path": f"{MODEL_DIR}/dataset_stats.json",
            "metadata_path": f"{MODEL_DIR}/metadata.json",
            "training_results": results
        }
        
    except Exception as e:
        print(f"Error during execution: {str(e)}")
        # Print exception traceback for debugging
        import traceback
        traceback.print_exc()
        
        error_info = {
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__,
            "traceback": traceback.format_exc(),
            "timestamp": pd.Timestamp.now().isoformat()
        }
        
        # Save error information
        with open(f"{MODEL_DIR}/error_log.json", "w") as f:
            json.dump(error_info, f, indent=2)
            
        return {
            "status": "error",
            "message": f"Error during execution: {str(e)}",
            "error_log_path": f"{MODEL_DIR}/error_log.json",
            "error_type": type(e).__name__
        }


@app.local_entrypoint()
def main():
    print("Starting model training...")
    result = train_model.remote()
    print("Process completed!")
    print(f"Results: {result}")
    print("\nTo download any generated files, run:")
    print("  modal volume get safety-scoring-volume /root/safety_scoring/models ./local_models")

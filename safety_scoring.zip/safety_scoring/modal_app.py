"""
Modal App for Safety Score Prediction Engine (v1.1)
"""

import modal

app = modal.App("safety-score-api")

image = (
    modal.Image.debian_slim()
    .pip_install(
        [
            "fastapi==0.110.0",
            "uvicorn[standard]==0.29.0",
            "pydantic==2.7.0",
            "pandas==2.2.2",
            "numpy==1.26.4",
            "joblib==1.4.2",
            "xgboost==2.0.3",
            "scikit-learn==1.4.2",
        ]
    )
    # Mount repo root and models
    .add_local_dir(".", remote_path="/root")
    .add_local_dir("local_models", remote_path="/root/local_models")
)

@app.function(image=image, min_containers=1)
@modal.asgi_app()
def fastapi_app():
    import sys
    if "/root" not in sys.path:
        sys.path.insert(0, "/root")
    # Import from safety_scoring/api.py
    from api_service import fastapi_app as app_instance
    return app_instance

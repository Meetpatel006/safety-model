"""
Comprehensive Test Suite for Safety Score Prediction Engine

This module provides comprehensive testing for the Safety Score Prediction Engine.
"""

import pandas as pd
import numpy as np
import json
import time
from datetime import datetime, timedelta
import requests
import sys
import os

# Add current directory to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from dataset_generator import SafetyScoreDatasetGenerator
from safety_score_model import SafetyScoreEnsemble
from train_safety_model import SafetyScoreTrainingPipeline

class SafetyScoreSystemTester:
    """Comprehensive test suite for the Safety Score Prediction Engine."""
    
    def __init__(self):
        """Initialize the tester."""
        self.test_results = {}
        self.api_base_url = "http://localhost:8000"
        
    def test_dataset_generation(self):
        """Test dataset generation functionality."""
        print("Testing Dataset Generation...")
        
        try:
            generator = SafetyScoreDatasetGenerator(random_seed=42)
            df = generator.generate_tourist_data(num_tourists=50, days=5)
            
            # Validate dataset structure based on schema
            required_columns = [
                'tourist_id', 'timestamp', 'latitude', 'longitude', 'location_name', 'state',
                'hour', 'is_night', 'month', 'speed_kmh', 'time_since_last_checkin',
                'location_risk_level', 'zone_risk_score', 'weather_condition', 'weather_safety_impact',
                'visibility_score', 'temperature', 'humidity', 'tourist_profile', 'has_medical_condition',
                'tourist_density', 'local_event_risk', 'communication_events', 'safety_score',
                'safety_score_category'
            ]
            
            missing_columns = [col for col in required_columns if col not in df.columns]
            assert len(missing_columns) == 0, f"Missing columns: {missing_columns}"
            
            # Validate data types and ranges based on schema
            assert df['safety_score'].min() >= 0, "Safety score should be >= 0"
            assert df['safety_score'].max() <= 100, "Safety score should be <= 100"
            assert df['tourist_id'].nunique() == 50, "Should have 50 unique tourists"
            
            # Validate schema-specific data types and ranges
            assert df['latitude'].min() >= 20, "Latitude should be reasonable for Northeast India"
            assert df['latitude'].max() <= 30, "Latitude should be reasonable for Northeast India"
            assert df['longitude'].min() >= 85, "Longitude should be reasonable for Northeast India"
            assert df['longitude'].max() <= 100, "Longitude should be reasonable for Northeast India"
            assert df['hour'].min() >= 0, "Hour should be 0-23"
            assert df['hour'].max() <= 23, "Hour should be 0-23"
            assert df['month'].min() >= 1, "Month should be 1-12"
            assert df['month'].max() <= 12, "Month should be 1-12"
            assert df['speed_kmh'].min() >= 0, "Speed should be >= 0"
            assert df['zone_risk_score'].min() >= 0, "Zone risk score should be >= 0"
            assert df['zone_risk_score'].max() <= 1, "Zone risk score should be <= 1"
            assert df['weather_safety_impact'].min() >= 0, "Weather safety impact should be >= 0"
            assert df['weather_safety_impact'].max() <= 1, "Weather safety impact should be <= 1"
            assert df['visibility_score'].min() >= 0, "Visibility score should be >= 0"
            assert df['visibility_score'].max() <= 1, "Visibility score should be <= 1"
            assert df['temperature'].min() >= 0, "Temperature should be reasonable"
            assert df['humidity'].min() >= 0, "Humidity should be >= 0"
            assert df['humidity'].max() <= 100, "Humidity should be <= 100"
            assert df['tourist_density'].min() >= 0, "Tourist density should be >= 0"
            assert df['tourist_density'].max() <= 100, "Tourist density should be <= 100"
            assert df['local_event_risk'].min() >= 0, "Local event risk should be >= 0"
            assert df['local_event_risk'].max() <= 1, "Local event risk should be <= 1"
            assert df['communication_events'].min() >= 0, "Communication events should be >= 0"
            
            # Validate categorical values
            valid_risk_levels = ['low', 'medium', 'high']
            assert df['location_risk_level'].isin(valid_risk_levels).all(), "Invalid risk levels"
            
            valid_weather = ['clear', 'light_rain', 'heavy_rain', 'storm', 'fog', 'snow']
            assert df['weather_condition'].isin(valid_weather).all(), "Invalid weather conditions"
            
            valid_profiles = ['beginner', 'moderate', 'experienced', 'adventure_seeker']
            assert df['tourist_profile'].isin(valid_profiles).all(), "Invalid tourist profiles"
            
            valid_categories = ['Very Safe', 'Safe', 'Moderate Risk', 'High Risk', 'Very High Risk']
            assert df['safety_score_category'].isin(valid_categories).all(), "Invalid safety categories"
            
            print("✅ Dataset generation test passed")
            self.test_results['dataset_generation'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Dataset generation test failed: {e}")
            self.test_results['dataset_generation'] = f'FAIL: {e}'
            return False
    
    def test_model_training(self):
        """Test model training and evaluation."""
        print("Testing Model Training...")
        
        try:
            # Generate sample data
            generator = SafetyScoreDatasetGenerator(random_seed=42)
            df = generator.generate_tourist_data(num_tourists=100, days=7)
            
            # Prepare data
            engineer = SafetyScoreFeatureEngineer()
            X_train, X_test, y_train, y_test = engineer.prepare_training_data(df)
            
            # Train model
            model = SafetyScoreEnsemble(random_state=42)
            training_results = model.train(X_train, y_train, X_test, y_test)
            
            # Validate training
            assert model.is_trained, "Model should be trained"
            assert model.ensemble_weights is not None, "Ensemble weights should be set"
            assert len(model.ensemble_weights) == 2, "Should have 2 ensemble weights"
            
            # Test predictions
            predictions = model.predict(X_test)
            assert len(predictions) == len(y_test), "Prediction count should match test data"
            assert all(0 <= p <= 100 for p in predictions), "Predictions should be in range [0, 100]"
            
            # Test single prediction
            sample_features = X_test.iloc[0].to_dict()
            single_pred = model.predict_single(sample_features)
            assert 'safety_score' in single_pred, "Single prediction should have safety_score"
            assert 'safety_category' in single_pred, "Single prediction should have safety_category"
            
            # Evaluate model
            metrics = model.evaluate(X_test, y_test)
            assert 'mae' in metrics, "Evaluation should include MAE"
            assert metrics['mae'] < 20, "MAE should be reasonable (< 20)"
            
            print("✅ Model training test passed")
            self.test_results['model_training'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Model training test failed: {e}")
            self.test_results['model_training'] = f'FAIL: {e}'
            return False
    
    def test_training_pipeline(self):
        """Test complete training pipeline."""
        print("Testing Training Pipeline...")
        
        try:
            # Create small config for testing
            config = {
                'random_seed': 42,
                'num_tourists': 50,
                'num_days': 5,
                'test_size': 0.2,
                'validation_size': 0.2,
                'feature_selection_method': 'random_forest',
                'num_features': 20,
                'cross_validation_folds': 3,
                'save_artifacts': True,
                'output_dir': 'test_safety_scoring_models'
            }
            
            # Run training pipeline
            pipeline = SafetyScoreTrainingPipeline(config)
            results = pipeline.run_training_pipeline()
            
            # Validate results
            assert results['status'] == 'success', "Pipeline should complete successfully"
            assert 'evaluation_results' in results, "Should have evaluation results"
            assert 'training_results' in results, "Should have training results"
            
            # Check if artifacts were saved
            assert os.path.exists('test_safety_scoring_models'), "Output directory should be created"
            
            print("✅ Training pipeline test passed")
            self.test_results['training_pipeline'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Training pipeline test failed: {e}")
            self.test_results['training_pipeline'] = f'FAIL: {e}'
            return False
    
    def test_api_endpoints(self):
        """Test API endpoints (requires running API server)."""
        print("Testing API Endpoints...")
        
        try:
            # Test health endpoint
            response = requests.get(f"{self.api_base_url}/health", timeout=5)
            assert response.status_code == 200, "Health endpoint should return 200"
            
            health_data = response.json()
            assert 'status' in health_data, "Health response should have status"
            
            # Test model info endpoint
            response = requests.get(f"{self.api_base_url}/model/info", timeout=5)
            assert response.status_code == 200, "Model info endpoint should return 200"
            
            model_info = response.json()
            assert 'model_type' in model_info, "Model info should have model_type"
            
            # Test prediction endpoint with simplified schema
            sample_request = {
                "timestamp": "2024-01-15T10:30:00",
                "location": {
                    "latitude": 23.8315,
                    "longitude": 91.2862,
                    "location_name": "Agartala",
                    "state": "Tripura"
                },
                "weather": {
                    "condition": "clear",
                    "temperature": 25.0,
                    "humidity": 60.0,
                    "visibility": 1.0
                },
                "tourist": {
                    "tourist_id": "test_tourist_1",
                    "profile_type": "moderate",
                    "has_medical_condition": False
                },
                "behavioral": {
                    "communication_events": 2,
                    "speed_kmh": 10.0
                },
                "environmental": {
                    "tourist_density": 50,
                    "local_event_risk": 0.2
                }
            }
            
            response = requests.post(f"{self.api_base_url}/predict", 
                                   json=sample_request, timeout=10)
            assert response.status_code == 200, "Prediction endpoint should return 200"
            
            prediction = response.json()
            assert 'safety_score' in prediction, "Prediction should have safety_score"
            assert 'safety_category' in prediction, "Prediction should have safety_category"
            assert 'recommendations' in prediction, "Prediction should have recommendations"
            
            print("✅ API endpoints test passed")
            self.test_results['api_endpoints'] = 'PASS'
            return True
            
        except requests.exceptions.ConnectionError:
            print("⚠️ API server not running, skipping API tests")
            self.test_results['api_endpoints'] = 'SKIP: API server not running'
            return False
        except Exception as e:
            print(f"❌ API endpoints test failed: {e}")
            self.test_results['api_endpoints'] = f'FAIL: {e}'
            return False
    
    def test_performance(self):
        """Test system performance."""
        print("Testing Performance...")
        
        try:
            # Generate larger dataset for performance testing
            generator = SafetyScoreDatasetGenerator(random_seed=42)
            df = generator.generate_tourist_data(num_tourists=200, days=10)
            
            # Test feature engineering performance
            start_time = time.time()
            engineer = SafetyScoreFeatureEngineer()
            df_engineered = engineer.engineer_features(df, 'safety_score')
            feature_time = time.time() - start_time
            
            # Test model training performance
            start_time = time.time()
            X_train, X_test, y_train, y_test = engineer.prepare_training_data(df_engineered)
            model = SafetyScoreEnsemble(random_state=42)
            model.train(X_train, y_train)
            training_time = time.time() - start_time
            
            # Test prediction performance
            start_time = time.time()
            predictions = model.predict(X_test)
            prediction_time = time.time() - start_time
            
            # Validate performance metrics
            assert feature_time < 30, f"Feature engineering should take < 30s, took {feature_time:.2f}s"
            assert training_time < 60, f"Model training should take < 60s, took {training_time:.2f}s"
            assert prediction_time < 5, f"Prediction should take < 5s, took {prediction_time:.2f}s"
            
            print(f"✅ Performance test passed")
            print(f"   Feature engineering: {feature_time:.2f}s")
            print(f"   Model training: {training_time:.2f}s")
            print(f"   Prediction: {prediction_time:.2f}s")
            
            self.test_results['performance'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Performance test failed: {e}")
            self.test_results['performance'] = f'FAIL: {e}'
            return False
    
    def test_data_quality(self):
        """Test data quality and edge cases."""
        print("Testing Data Quality...")
        
        try:
            generator = SafetyScoreDatasetGenerator(random_seed=42)
            df = generator.generate_tourist_data(num_tourists=100, days=5)
            
            # Test for missing values
            missing_values = df.isnull().sum()
            high_missing = missing_values[missing_values > len(df) * 0.5]
            assert len(high_missing) == 0, f"Too many missing values in: {high_missing.to_dict()}"
            
            # Test for outliers in safety scores
            safety_scores = df['safety_score']
            q1, q3 = safety_scores.quantile([0.25, 0.75])
            iqr = q3 - q1
            outliers = safety_scores[(safety_scores < q1 - 1.5 * iqr) | (safety_scores > q3 + 1.5 * iqr)]
            assert len(outliers) < len(df) * 0.1, "Too many outliers in safety scores"
            
            # Test data consistency based on schema
            assert df['safety_score'].min() >= 0, "Safety scores should be >= 0"
            assert df['safety_score'].max() <= 100, "Safety scores should be <= 100"
            assert df['speed_kmh'].min() >= 0, "Speed should be >= 0"
            assert df['time_since_last_checkin'].min() >= 0, "Time since checkin should be >= 0"
            assert df['zone_risk_score'].min() >= 0, "Zone risk score should be >= 0"
            assert df['zone_risk_score'].max() <= 1, "Zone risk score should be <= 1"
            assert df['weather_safety_impact'].min() >= 0, "Weather safety impact should be >= 0"
            assert df['weather_safety_impact'].max() <= 1, "Weather safety impact should be <= 1"
            assert df['visibility_score'].min() >= 0, "Visibility score should be >= 0"
            assert df['visibility_score'].max() <= 1, "Visibility score should be <= 1"
            assert df['temperature'].min() >= -10, "Temperature should be reasonable"
            assert df['temperature'].max() <= 50, "Temperature should be reasonable"
            assert df['humidity'].min() >= 0, "Humidity should be >= 0"
            assert df['humidity'].max() <= 100, "Humidity should be <= 100"
            assert df['tourist_density'].min() >= 0, "Tourist density should be >= 0"
            assert df['tourist_density'].max() <= 100, "Tourist density should be <= 100"
            assert df['local_event_risk'].min() >= 0, "Local event risk should be >= 0"
            assert df['local_event_risk'].max() <= 1, "Local event risk should be <= 1"
            assert df['communication_events'].min() >= 0, "Communication events should be >= 0"
            
            print("✅ Data quality test passed")
            self.test_results['data_quality'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Data quality test failed: {e}")
            self.test_results['data_quality'] = f'FAIL: {e}'
            return False
    
    def test_schema_validation(self):
        """Test schema validation functionality."""
        print("Testing Schema Validation...")
        
        try:
            # Generate sample data
            generator = SafetyScoreDatasetGenerator(random_seed=42)
            df = generator.generate_tourist_data(num_tourists=20, days=3)
            
            # Test schema validation
            model = SafetyScoreEnsemble()
            validation_result = model.validate_feature_set(df)
            
            # Validate schema validation results
            assert 'is_valid' in validation_result, "Validation result should have is_valid"
            assert 'missing_schema_features' in validation_result, "Should have missing_schema_features"
            assert 'extra_features' in validation_result, "Should have extra_features"
            assert 'schema_completeness' in validation_result, "Should have schema_completeness"
            
            # Test with sample record from model
            sample_record = model.create_sample_record()
            sample_df = pd.DataFrame([sample_record])
            sample_validation = model.validate_feature_set(sample_df)
            
            # Sample record should pass validation
            assert sample_validation['is_valid'], "Sample record should pass schema validation"
            assert sample_validation['schema_completeness'] == 100.0, "Sample record should be 100% complete"
            
            # Test prediction with schema-validated record
            prediction = model.predict_single(sample_record)
            assert 'safety_score' in prediction, "Prediction should have safety_score"
            assert 'safety_category' in prediction, "Prediction should have safety_category"
            assert 'contributing_factors' in prediction, "Prediction should have contributing_factors"
            assert 'confidence' in prediction, "Prediction should have confidence"
            
            # Validate prediction ranges
            assert 0 <= prediction['safety_score'] <= 100, "Safety score should be in range [0, 100]"
            assert prediction['safety_category'] in ['Very Safe', 'Safe', 'Moderate Risk', 'High Risk', 'Very High Risk'], "Invalid safety category"
            assert 0 <= prediction['confidence'] <= 100, "Confidence should be in range [0, 100]"
            
            print("✅ Schema validation test passed")
            self.test_results['schema_validation'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Schema validation test failed: {e}")
            self.test_results['schema_validation'] = f'FAIL: {e}'
            return False
    
    def test_schema_template_generation(self):
        """Test schema template generation."""
        print("Testing Schema Template Generation...")
        
        try:
            model = SafetyScoreEnsemble()
            
            # Test schema template generation
            model.save_schema_template('test_schema_template.json')
            
            # Validate schema template file exists
            assert os.path.exists('test_schema_template.json'), "Schema template file should be created"
            
            # Load and validate schema template
            with open('test_schema_template.json', 'r') as f:
                schema_template = json.load(f)
            
            # Validate schema structure
            assert 'description' in schema_template, "Schema should have description"
            assert 'version' in schema_template, "Schema should have version"
            assert 'fields' in schema_template, "Schema should have fields"
            
            # Validate all 25 fields are present
            expected_fields = [
                'tourist_id', 'timestamp', 'latitude', 'longitude', 'location_name', 'state',
                'hour', 'is_night', 'month', 'speed_kmh', 'time_since_last_checkin',
                'location_risk_level', 'zone_risk_score', 'weather_condition', 'weather_safety_impact',
                'visibility_score', 'temperature', 'humidity', 'tourist_profile', 'has_medical_condition',
                'tourist_density', 'local_event_risk', 'communication_events', 'safety_score',
                'safety_score_category'
            ]
            
            schema_fields = list(schema_template['fields'].keys())
            missing_fields = [f for f in expected_fields if f not in schema_fields]
            assert len(missing_fields) == 0, f"Missing fields in schema: {missing_fields}"
            
            # Validate field structure
            for field_name, field_info in schema_template['fields'].items():
                assert 'type' in field_info, f"Field {field_name} should have type"
                assert 'description' in field_info, f"Field {field_name} should have description"
                assert 'example' in field_info, f"Field {field_name} should have example"
            
            # Clean up test file
            os.remove('test_schema_template.json')
            
            print("✅ Schema template generation test passed")
            self.test_results['schema_template_generation'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Schema template generation test failed: {e}")
            self.test_results['schema_template_generation'] = f'FAIL: {e}'
            return False
    
    def test_model_sample_record_generation(self):
        """Test model's sample record generation functionality."""
        print("Testing Model Sample Record Generation...")
        
        try:
            model = SafetyScoreEnsemble()
            
            # Generate sample record
            sample_record = model.create_sample_record()
            
            # Validate sample record structure
            expected_fields = [
                'tourist_id', 'timestamp', 'latitude', 'longitude', 'location_name', 'state',
                'hour', 'is_night', 'month', 'speed_kmh', 'time_since_last_checkin',
                'location_risk_level', 'zone_risk_score', 'weather_condition', 'weather_safety_impact',
                'visibility_score', 'temperature', 'humidity', 'tourist_profile', 'has_medical_condition',
                'tourist_density', 'local_event_risk', 'communication_events', 'safety_score',
                'safety_score_category'
            ]
            
            # Check all fields are present
            missing_fields = [f for f in expected_fields if f not in sample_record]
            assert len(missing_fields) == 0, f"Missing fields in sample record: {missing_fields}"
            
            # Validate data types
            assert isinstance(sample_record['tourist_id'], str), "tourist_id should be string"
            assert isinstance(sample_record['timestamp'], datetime), "timestamp should be datetime"
            assert isinstance(sample_record['latitude'], (int, float)), "latitude should be numeric"
            assert isinstance(sample_record['longitude'], (int, float)), "longitude should be numeric"
            assert isinstance(sample_record['location_name'], str), "location_name should be string"
            assert isinstance(sample_record['state'], str), "state should be string"
            assert isinstance(sample_record['hour'], int), "hour should be integer"
            assert isinstance(sample_record['is_night'], bool), "is_night should be boolean"
            assert isinstance(sample_record['month'], int), "month should be integer"
            assert isinstance(sample_record['speed_kmh'], (int, float)), "speed_kmh should be numeric"
            assert isinstance(sample_record['time_since_last_checkin'], int), "time_since_last_checkin should be integer"
            assert isinstance(sample_record['location_risk_level'], str), "location_risk_level should be string"
            assert isinstance(sample_record['zone_risk_score'], (int, float)), "zone_risk_score should be numeric"
            assert isinstance(sample_record['weather_condition'], str), "weather_condition should be string"
            assert isinstance(sample_record['weather_safety_impact'], (int, float)), "weather_safety_impact should be numeric"
            assert isinstance(sample_record['visibility_score'], (int, float)), "visibility_score should be numeric"
            assert isinstance(sample_record['temperature'], (int, float)), "temperature should be numeric"
            assert isinstance(sample_record['humidity'], (int, float)), "humidity should be numeric"
            assert isinstance(sample_record['tourist_profile'], str), "tourist_profile should be string"
            assert isinstance(sample_record['has_medical_condition'], bool), "has_medical_condition should be boolean"
            assert isinstance(sample_record['tourist_density'], int), "tourist_density should be integer"
            assert isinstance(sample_record['local_event_risk'], (int, float)), "local_event_risk should be numeric"
            assert isinstance(sample_record['communication_events'], int), "communication_events should be integer"
            assert isinstance(sample_record['safety_score'], (int, float)), "safety_score should be numeric"
            assert isinstance(sample_record['safety_score_category'], str), "safety_score_category should be string"
            
            # Validate value ranges
            assert 0 <= sample_record['hour'] <= 23, "Hour should be 0-23"
            assert 1 <= sample_record['month'] <= 12, "Month should be 1-12"
            assert sample_record['speed_kmh'] >= 0, "Speed should be >= 0"
            assert sample_record['time_since_last_checkin'] >= 0, "Time since checkin should be >= 0"
            assert 0 <= sample_record['zone_risk_score'] <= 1, "Zone risk score should be 0-1"
            assert 0 <= sample_record['weather_safety_impact'] <= 1, "Weather safety impact should be 0-1"
            assert 0 <= sample_record['visibility_score'] <= 1, "Visibility score should be 0-1"
            assert sample_record['temperature'] >= -10, "Temperature should be reasonable"
            assert sample_record['temperature'] <= 50, "Temperature should be reasonable"
            assert 0 <= sample_record['humidity'] <= 100, "Humidity should be 0-100"
            assert 0 <= sample_record['tourist_density'] <= 100, "Tourist density should be 0-100"
            assert 0 <= sample_record['local_event_risk'] <= 1, "Local event risk should be 0-1"
            assert sample_record['communication_events'] >= 0, "Communication events should be >= 0"
            assert 0 <= sample_record['safety_score'] <= 100, "Safety score should be 0-100"
            
            # Validate categorical values
            valid_risk_levels = ['low', 'medium', 'high']
            assert sample_record['location_risk_level'] in valid_risk_levels, "Invalid risk level"
            
            valid_weather = ['clear', 'light_rain', 'heavy_rain', 'storm', 'fog', 'snow']
            assert sample_record['weather_condition'] in valid_weather, "Invalid weather condition"
            
            valid_profiles = ['beginner', 'moderate', 'experienced', 'adventure_seeker']
            assert sample_record['tourist_profile'] in valid_profiles, "Invalid tourist profile"
            
            valid_categories = ['Very Safe', 'Safe', 'Moderate Risk', 'High Risk', 'Very High Risk']
            assert sample_record['safety_score_category'] in valid_categories, "Invalid safety category"
            
            # Test multiple sample records for variety
            sample_records = [model.create_sample_record() for _ in range(10)]
            unique_locations = set(record['location_name'] for record in sample_records)
            unique_weather = set(record['weather_condition'] for record in sample_records)
            unique_profiles = set(record['tourist_profile'] for record in sample_records)
            
            # Should have some variety in generated samples
            assert len(unique_locations) > 1, "Should generate variety in locations"
            assert len(unique_weather) > 1, "Should generate variety in weather"
            assert len(unique_profiles) > 1, "Should generate variety in profiles"
            
            print("✅ Model sample record generation test passed")
            self.test_results['model_sample_record_generation'] = 'PASS'
            return True
            
        except Exception as e:
            print(f"❌ Model sample record generation test failed: {e}")
            self.test_results['model_sample_record_generation'] = f'FAIL: {e}'
            return False
    
    def run_all_tests(self):
        """Run all tests and generate report."""
        print("Running Safety Score Prediction Engine Test Suite (Schema-Based)")
        print("=" * 70)
        
        tests = [
            self.test_dataset_generation,
            self.test_model_training,
            self.test_training_pipeline,
            self.test_data_quality,
            self.test_performance,
            self.test_schema_validation,
            self.test_schema_template_generation,
            self.test_model_sample_record_generation,
            self.test_api_endpoints
        ]
        
        passed = 0
        total = len(tests)
        
        for test in tests:
            try:
                if test():
                    passed += 1
            except Exception as e:
                print(f"❌ Test {test.__name__} failed with exception: {e}")
        
        print("=" * 60)
        print(f"Test Results: {passed}/{total} tests passed")
        
        # Generate detailed report
        report = {
            'timestamp': datetime.now().isoformat(),
            'test_suite': 'Safety Score Prediction Engine (Schema-Based)',
            'schema_version': '1.0',
            'schema_fields': 25,
            'total_tests': total,
            'passed_tests': passed,
            'failed_tests': total - passed,
            'success_rate': f"{(passed/total)*100:.1f}%",
            'test_results': self.test_results,
            'schema_validation': {
                'expected_fields': [
                    'tourist_id', 'timestamp', 'latitude', 'longitude', 'location_name', 'state',
                    'hour', 'is_night', 'month', 'speed_kmh', 'time_since_last_checkin',
                    'location_risk_level', 'zone_risk_score', 'weather_condition', 'weather_safety_impact',
                    'visibility_score', 'temperature', 'humidity', 'tourist_profile', 'has_medical_condition',
                    'tourist_density', 'local_event_risk', 'communication_events', 'safety_score',
                    'safety_score_category'
                ],
                'field_count': 25
            }
        }
        
        # Save report
        with open('safety_score_test_report.json', 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"Detailed test report saved to: safety_score_test_report.json")
        
        return report

def main():
    """Run the test suite."""
    tester = SafetyScoreSystemTester()
    report = tester.run_all_tests()
    
    if report['passed_tests'] == report['total_tests']:
        print("🎉 All tests passed! Safety Score Prediction Engine (Schema-Based) is ready.")
        print(f"✅ Schema validation: {report['schema_fields']} fields validated")
        return 0
    else:
        print("⚠️ Some tests failed. Please review the results.")
        print(f"Schema validation: {report['schema_fields']} fields expected")
        return 1

if __name__ == "__main__":
    exit(main())

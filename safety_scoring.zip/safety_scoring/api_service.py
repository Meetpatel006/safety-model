"""
FastAPI Service for Safety Score Prediction Engine

This module provides a REST API for real-time safety score prediction
as specified in the ml_model_docs.md requirements.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import pandas as pd
import numpy as np
import joblib
import os
from datetime import datetime
import logging

from safety_score_model import SafetyScoreEnsemble

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
fastapi_app = FastAPI(
    title="Safety Score Prediction Engine API",
    description="Real-time safety score prediction for tourists in Northeast India",
    version="1.0.0"
)

# Add CORS middleware
fastapi_app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables for model and preprocessing
model = None
model_loaded = False

# Pydantic models for API requests/responses
class SafetyScoreData(BaseModel):
    tourist_id: str = Field(..., description="Unique tourist identifier")
    timestamp: datetime = Field(..., description="Timestamp of the event")
    latitude: float = Field(..., description="Current latitude")
    longitude: float = Field(..., description="Current longitude")
    location_name: str = Field(..., description="Name of the location")
    state: str = Field(..., description="State name")
    hour: int = Field(..., description="Hour of the day")
    is_night: bool = Field(..., description="Whether it's nighttime")
    month: int = Field(..., description="Month of the year")
    
    # Location and movement features
    speed_kmh: float = Field(0, ge=0, description="Speed in kilometers per hour")
    time_since_last_checkin: int = Field(..., description="Time since last check-in")
    location_risk_level: str = Field(..., description="Risk level of the location")
    zone_risk_score: float = Field(..., description="Risk score for the zone")
    
    # Weather and environmental features
    weather_condition: str = Field(..., description="Weather condition")
    weather_safety_impact: float = Field(..., description="Weather impact on safety")
    visibility_score: float = Field(..., description="Visibility score")
    temperature: float = Field(..., description="Temperature in Celsius")
    humidity: float = Field(..., description="Humidity percentage")
    
    # Tourist profile features
    tourist_profile: str = Field(..., description="Tourist profile type")
    has_medical_condition: bool = Field(False, description="Has medical condition")
    
    # Environmental context
    tourist_density: int = Field(..., description="Tourist density in the area")
    local_event_risk: float = Field(..., description="Risk from local events")
    
    # Behavioral features
    communication_events: int = Field(0, ge=0, description="Number of communication events")

class SafetyScoreRequest(BaseModel):
    # Using the consolidated SafetyScoreData model
    data: SafetyScoreData = Field(..., description="Safety score input data")

class ContributingFactor(BaseModel):
    factor: str = Field(..., description="Factor name")
    importance: float = Field(..., description="Importance score")
    value: float = Field(..., description="Factor value")

class SafetyScoreResponse(BaseModel):
    safety_score: float = Field(..., description="Predicted safety score (0-100)")
    safety_category: str = Field(..., description="Safety category")
    confidence: float = Field(..., description="Prediction confidence (0-100)")
    contributing_factors: List[ContributingFactor] = Field(..., description="Top contributing factors")
    recommendations: List[str] = Field(..., description="Safety recommendations")
    timestamp: datetime = Field(..., description="Prediction timestamp")

class BatchSafetyScoreRequest(BaseModel):
    requests: List[SafetyScoreRequest] = Field(..., description="List of safety score requests")

class BatchSafetyScoreResponse(BaseModel):
    predictions: List[SafetyScoreResponse] = Field(..., description="List of safety score predictions")
    processing_time_ms: float = Field(..., description="Total processing time in milliseconds")

class HealthResponse(BaseModel):
    status: str = Field(..., description="Service status")
    model_loaded: bool = Field(..., description="Whether model is loaded")
    timestamp: datetime = Field(..., description="Health check timestamp")

def load_model_and_preprocessing():
    """Load the trained model and preprocessing artifacts."""
    global model, model_loaded
    
    try:
        # Reset global variables
        model = None
        model_loaded = False
        
        # Look for model in the local_models/models directory first
        candidate_model_paths = [
            os.path.join(os.path.dirname(__file__), "local_models", "models", "safety_score_model.pkl"),
            os.path.join(os.getcwd(), "local_models", "models", "safety_score_model.pkl"),
            "/root/safety_scoring/models/safety_score_model.pkl",
            "/root/local_models/safety_score_model.pkl",
            os.path.join(os.path.dirname(__file__), "..", "local_models", "safety_score_model.pkl"),
        ]
        
        logger.info("Attempting to load model from available paths...")

        found_model_path = None
        for p in candidate_model_paths:
            p_exp = os.path.abspath(p)
            if os.path.exists(p_exp):
                found_model_path = p_exp
                break

        if found_model_path:
            logger.info(f"Loading model from: {found_model_path}")
            model = SafetyScoreEnsemble()
            try:
                model.load_model(found_model_path)
                logger.info("Model loaded successfully")
            except Exception as e:
                # Attempt graceful fallback: directly inspect the file contents
                logger.warning(f"Primary model loader failed: {e}. Attempting fallback loading strategy.")
                try:
                    raw_obj = joblib.load(found_model_path)
                    # If raw_obj is a dict with nested model, try to extract
                    if isinstance(raw_obj, dict):
                        # Common keys: 'model', 'estimator', 'rf_model', 'xgb_model'
                        if 'rf_model' in raw_obj or 'xgb_model' in raw_obj:
                            model.rf_model = raw_obj.get('rf_model')
                            model.xgb_model = raw_obj.get('xgb_model')
                            model.ensemble_weights = raw_obj.get('ensemble_weights', (0.5, 0.5))
                            model.feature_importance = raw_obj.get('feature_importance')
                            model.is_trained = True
                        else:
                            # If it's a single model, use it as rf_model
                            model.rf_model = raw_obj
                            model.ensemble_weights = (1.0, 0.0)  # Only use RF model
                            model.is_trained = True
                    elif hasattr(raw_obj, 'predict'):
                        # If raw_obj is a model itself
                        model.rf_model = raw_obj
                        model.ensemble_weights = (1.0, 0.0)  # Only use RF model
                        model.is_trained = True
                    elif 'model' in raw_obj or 'estimator' in raw_obj:
                            candidate = raw_obj.get('model') or raw_obj.get('estimator')
                            if hasattr(candidate, 'predict'):
                                model.rf_model = candidate
                                model.ensemble_weights = (1.0, 0.0)
                                model.is_trained = True
                            else:
                            # Not a recognized dict shape; raise to outer except
                                raise ValueError('Unrecognized dict format for model file')
                    elif hasattr(raw_obj, 'predict'):
                        # Single estimator saved — treat as RF fallback
                        model.rf_model = raw_obj
                        model.ensemble_weights = (1.0, 0.0)
                        model.is_trained = True
                    elif isinstance(raw_obj, (list, tuple)):
                        # Map positional items if possible
                        try:
                            model.rf_model = raw_obj[0]
                            model.xgb_model = raw_obj[1] if len(raw_obj) > 1 else None
                            model.ensemble_weights = raw_obj[2] if len(raw_obj) > 2 else (0.5, 0.5)
                            model.feature_importance = raw_obj[3] if len(raw_obj) > 3 else None
                            model.is_trained = raw_obj[4] if len(raw_obj) > 4 else True
                        except Exception:
                            raise ValueError('Unrecognized sequence format for model file')
                    else:
                        raise ValueError('Unsupported model object type')

                    # Validate that model has required methods
                    if not hasattr(model.rf_model, 'predict') and not hasattr(model, 'predict_single'):
                        logger.error('Loaded model does not have required prediction methods')
                        return False
                    
                    logger.info('Fallback model loading succeeded; model object wired into SafetyScoreEnsemble')
                except Exception as e2:
                    logger.error(f'Error loading model: {e2}')
                    return False
        else:
            logger.error(f"Model file not found in candidates: {candidate_model_paths}")
            return False
            
        # Final validation of model object
        if model is None or not hasattr(model, 'predict_single'):
            logger.error('Model validation failed: Missing required methods')
            return False

        # Note: feature engineering and preprocessing artifacts are optional.
        # This simplified loader focuses on loading the model. If preprocessing artifacts
        # exist in the local_models directory, the model or caller can handle them
        # via its own compatibility helpers. We avoid importing or instantiating an
        # external feature engineering class to reduce runtime dependencies.

        model_loaded = True
        return True
    except Exception as e:
        logger.error(f"Error loading model: {e}")
        model_loaded = False
        return False

def convert_request_to_features(request: SafetyScoreRequest) -> Dict[str, Any]:
    """Convert API request to feature dictionary."""
    data = request.data
    features = {
        # Location and temporal features
    'timestamp': data.timestamp,
        'tourist_id': data.tourist_id,
        'latitude': data.latitude,
        'longitude': data.longitude,
        'location_name': data.location_name,
        'state': data.state,
        'hour': data.hour,
        'is_night': data.is_night,
        'month': data.month,
        
        # Movement and location risk features
        'speed_kmh': data.speed_kmh,
        'time_since_last_checkin': data.time_since_last_checkin,
        'location_risk_level': data.location_risk_level,
        'zone_risk_score': data.zone_risk_score,
        
        # Weather features
        'weather_condition': data.weather_condition,
        'weather_safety_impact': data.weather_safety_impact,
        'visibility_score': data.visibility_score,
        'temperature': data.temperature,
        'humidity': data.humidity,
        
        # Tourist profile features
        'tourist_profile': data.tourist_profile,
        'has_medical_condition': data.has_medical_condition,
        
        # Environmental features
        'tourist_density': data.tourist_density,
        'local_event_risk': data.local_event_risk,
        
        # Behavioral features
        'communication_events': data.communication_events
    }
    return features


def generate_recommendations(safety_score: float, contributing_factors: List[Dict]) -> List[str]:
    """Generate safety recommendations based on safety score and contributing factors."""
    recommendations = []
    
    if safety_score < 40:
        recommendations.append("⚠️ HIGH RISK: Consider moving to a safer location immediately")
        recommendations.append("📞 Contact emergency services if needed")
        recommendations.append("👥 Stay with your group and avoid isolation")
    elif safety_score < 60:
        recommendations.append("⚠️ MODERATE RISK: Exercise caution and stay alert")
        recommendations.append("📍 Share your location with trusted contacts")
        recommendations.append("🔋 Ensure your device is charged")
    elif safety_score < 80:
        recommendations.append("✅ SAFE: Continue with normal activities")
        recommendations.append("📱 Keep your safety app active")
    else:
        recommendations.append("✅ VERY SAFE: Enjoy your visit!")
        recommendations.append("📸 Feel free to explore and take photos")
    
    # Add specific recommendations based on contributing factors
    for factor in contributing_factors[:3]:  # Top 3 factors
        factor_name = factor['factor']
        factor_value = factor['value']
        
        if 'weather' in factor_name.lower() and factor_value > 0.5:
            recommendations.append("🌧️ Weather alert: Check weather conditions before proceeding")
        elif 'density' in factor_name.lower() and factor_value < 30:
            recommendations.append("👥 Low tourist density: Consider moving to a more populated area")
        elif 'location' in factor_name.lower() and factor_value > 0.6:
            recommendations.append("⚠️ High risk location: Exercise extra caution")
        elif 'communication' in factor_name.lower() and factor_value < 1:
            recommendations.append("📱 Low communication: Try to stay in contact with others")
    
    return recommendations

@fastapi_app.on_event("startup")
async def startup_event():
    """Load model and preprocessing artifacts on startup."""
    logger.info("Starting Safety Score Prediction API...")
    success = load_model_and_preprocessing()
    if success:
        logger.info("API ready for predictions!")
    else:
        logger.error("Failed to load model. API may not work correctly.")

@fastapi_app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(
        status="healthy" if model_loaded else "unhealthy",
        model_loaded=model_loaded,
        timestamp=datetime.now()
    )

@fastapi_app.post("/predict", response_model=SafetyScoreResponse)
async def predict_safety_score(request: SafetyScoreRequest):
    """Predict safety score for a single tourist."""
    if not model_loaded or model is None:
        # Try to load the model if it's not loaded
        success = load_model_and_preprocessing()
        if not success or model is None:
            raise HTTPException(status_code=503, detail="Model not loaded or initialization failed")
    
    try:
        # Convert request to features
        features = convert_request_to_features(request)
        
        # Build a DataFrame from the incoming raw features. We no longer run
        # an external feature engineering pipeline here; instead we pass either
        # the raw features or select the columns that match the model's
        # expected `feature_names` (if available).
        feature_df = pd.DataFrame([features])

        model_input = None
        if model is not None and getattr(model, 'feature_names', None):
            expected = model.feature_names
            present = [f for f in expected if f in feature_df.columns]
            if present:
                model_input = feature_df[present].iloc[0].to_dict()
            else:
                # No matching expected columns found; send the raw row and rely on
                # model.predict_single compatibility helpers to handle missing encoding.
                logger.warning('No expected model feature columns present; passing raw input row')
                model_input = feature_df.iloc[0].to_dict()
        else:
            # Model has no declared feature_names; pass raw features
            model_input = feature_df.iloc[0].to_dict()

        # Make prediction using model_input
        if not hasattr(model, 'predict_single'):
            logger.error("Model doesn't have predict_single method")
            raise HTTPException(status_code=500, detail="Invalid model configuration")
            
        try:
            prediction = model.predict_single(model_input)
            if not isinstance(prediction, dict) or 'safety_score' not in prediction:
                logger.error("Invalid prediction format")
                raise HTTPException(status_code=500, detail="Model returned invalid prediction format")
        except Exception as pred_error:
            logger.error(f"Prediction failed: {str(pred_error)}")
            raise HTTPException(status_code=500, detail=f"Prediction failed: {str(pred_error)}")
        
        # Generate recommendations
        recommendations = generate_recommendations(
            prediction['safety_score'], 
            prediction.get('contributing_factors', [])
        )
        
        # Convert contributing factors to response format
        contributing_factors = [
            ContributingFactor(
                factor=factor['factor'],
                importance=factor['importance'],
                value=factor['value']
            )
            for factor in prediction['contributing_factors']
        ]
        
        return SafetyScoreResponse(
            safety_score=prediction['safety_score'],
            safety_category=prediction['safety_category'],
            confidence=prediction['confidence'],
            contributing_factors=contributing_factors,
            recommendations=recommendations,
            timestamp=datetime.now()
        )
        
    except Exception as e:
        logger.error(f"Error in prediction: {e}")
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

@fastapi_app.post("/predict/batch", response_model=BatchSafetyScoreResponse)
async def predict_safety_score_batch(request: BatchSafetyScoreRequest):
    """Predict safety scores for multiple tourists."""
    if not model_loaded:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    start_time = datetime.now()
    
    try:
        predictions = []
        
        for req in request.requests:
            # Convert request to features
            features = convert_request_to_features(req)
            
            # Create DataFrame from raw features and prepare model input.
            feature_df = pd.DataFrame([features])

            model_input = None
            if model is not None and getattr(model, 'feature_names', None):
                expected = model.feature_names
                present = [f for f in expected if f in feature_df.columns]
                if present:
                    model_input = feature_df[present].iloc[0].to_dict()
                else:
                    logger.warning('No expected model feature columns present for batch item; passing raw input row')
                    model_input = feature_df.iloc[0].to_dict()
            else:
                model_input = feature_df.iloc[0].to_dict()

            # Make prediction
            prediction = model.predict_single(model_input)
            
            # Generate recommendations
            recommendations = generate_recommendations(
                prediction['safety_score'], 
                prediction['contributing_factors']
            )
            
            # Convert contributing factors to response format
            contributing_factors = [
                ContributingFactor(
                    factor=factor['factor'],
                    importance=factor['importance'],
                    value=factor['value']
                )
                for factor in prediction['contributing_factors']
            ]
            
            predictions.append(SafetyScoreResponse(
                safety_score=prediction['safety_score'],
                safety_category=prediction['safety_category'],
                confidence=prediction['confidence'],
                contributing_factors=contributing_factors,
                recommendations=recommendations,
                timestamp=datetime.now()
            ))
        
        processing_time = (datetime.now() - start_time).total_seconds() * 1000
        
        return BatchSafetyScoreResponse(
            predictions=predictions,
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        logger.error(f"Error in batch prediction: {e}")
        raise HTTPException(status_code=500, detail=f"Batch prediction failed: {str(e)}")

@fastapi_app.get("/model/info")
async def get_model_info():
    """Get information about the loaded model."""
    if not model_loaded:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    return {
        "model_type": "Random Forest + XGBoost Ensemble",
        "ensemble_weights": model.ensemble_weights if model else None,
        "feature_count": len(model.feature_names) if model and model.feature_names else 0,
        "is_trained": model.is_trained if model else False,
        "feature_importance_available": model.feature_importance is not None if model else False
    }

@fastapi_app.get("/model/features")
async def get_feature_importance():
    """Get feature importance information."""
    if not model_loaded or not model.feature_importance is not None:
        raise HTTPException(status_code=503, detail="Feature importance not available")
    
    return {
        "feature_importance": model.feature_importance.to_dict('records'),
        "top_features": model.feature_importance.head(10).to_dict('records')
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(fastapi_app, host="0.0.0.0", port=8000)
